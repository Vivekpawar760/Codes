import { Component, Inject, Renderer2, OnInit } from '@angular/core';
import { SharedService } from './_helper/shared.service';
import { Meta } from '@angular/platform-browser';
import { ActivatedRoute, NavigationEnd, Route, Router } from '@angular/router';
import { filter, first, map, mergeMap } from 'rxjs/operators';
import { SeoserviceService } from './Seoservice/seoservice.service';
import { location } from './_model/shared';
import { environment } from "../environments/environment";
import * as moment from 'moment';
declare var $: any;
import * as SN from './api-service-list';
import { ApiService } from './_helper';
import { DOCUMENT } from '@angular/common';
import { PartnerComponent } from './partner/Partner.component';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ocxeeweb';
  isFound = false;
  public lat;
  public lng;
  location: location;

  subscription: any;
  loadAPI: Promise<any>;
  key: string
  val: number = 0
  constructor(
    private _renderer2: Renderer2,
    @Inject(DOCUMENT) private _document: Document,
    @Inject('isBrowser')
    private _sharedService: SharedService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private seoService: SeoserviceService,
    private meta: Meta,
    private http: HttpClient,
    private ApiService: ApiService,
    @Inject(DOCUMENT) private document: Document,
  ) {
    // this.getKey()
    this.getKey2().subscribe(data => {
      // console.log(data)
      let script = this._renderer2.createElement('script');
      script.type = "text/javascript"
      script.text = "";
      script.Id = "MapApi";
      let src = "https://maps.googleapis.com/maps/api/js?key=" + data["key"] + "&libraries=places&language=en?onload=onLoadCallback"
      script.src = `${src}`;
      script.async = true
      script.defer = true
      this._renderer2.appendChild(this._document.body, script);
    });
    if (!['192.168.1.45', 'www.ocxee.com', 'localhost', 'ocxeeweb.dnktech.in'].includes(this.document.location.hostname)) {
      let r: Route = {
        path: '',
        component: PartnerComponent,
        children: [
          { path: '', loadChildren: () => import('./cplanding/cplanding.module').then(m => m.CplandingModule) },
          { path: '**', loadChildren: () => import('./not-found-component/not-found-component.module').then(m => m.NotFoundComponentModule) },
        ]
      };
      this.router.resetConfig([r]);
      // this.router.navigate(['']); // navigating to LoginComponent
    }
  }


  ngOnInit(): void {
    this.router.events.pipe(
      filter(e => e instanceof NavigationEnd),
      map(e => this.activatedRoute),
      map((route) => {
        while (route.firstChild) route = route.firstChild;
        return route;
      }),
      filter((route) => route.outlet === 'primary'),
      mergeMap((route) => route.data),
    ).subscribe(data => {
      // console.log('Seo app');
      // console.log(data['seo']);
      if (data['seo']) {
        let seoData = data['seo'];
        this.seoService.updateTitle(seoData['title']);
        this.seoService.updateMetaTags(seoData['metaTags']);
      }

    });

    // const scriptList = document.querySelectorAll("script[type='text/javascript']")
    // const convertedNodeList = Array.from(scriptList)
    // const  testScript = convertedNodeList.find(script => script.id === "MapApi")
    // testScript.parentNode.removeChild(testScript)
    // var element = document.getElementById("MapApi");
    // element.parentNode.removeChild(element);

    // this.getLocation();
  }
  getKey2(): Observable<any> {
    // let req = {
    //   settingKey: "Google_Api_Key"
    // }
    // return this.http.post(environment.ApiUrl+SN.getSettingData, req)
    return this.http.get("../../assets/daynamic.json")
  }
  async getKey() {
    let req = {
      settingKey: "Google_Api_Key"
    }
    let sesdata = localStorage.getItem("U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=")
    let session
    if (localStorage.getItem('U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=') != null) {
      session = JSON.parse(this.ApiService.DecryptObject(localStorage.getItem("U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=").toString()))
    }
    let data
    if (session == undefined || session == '') {
      data = await this.http.post(environment.ApiUrl + SN.getSettingData, { fshdjfdh: this.ApiService.EncryptObject(req) }).toPromise().catch((e) => {
        return e
      });
      data = this.ApiService.DecryptObject(data["QYUEIMSHNSGMDM"])["data"]
    } else {
      data = session
    }
    environment.MAP_KEY = data["key"]
    $(document).ready(function ($) {
      $('script').each(function () {
        if (this.src.search("https://maps.googleapis.com/maps/api/js?key=") != -1) {
          alert("Hello")
          this.parentNode.removeChild(this);
        }
      });
    });
    let script = this._renderer2.createElement('script');
    script.type = "text/javascript"
    script.text = "";
    script.id = "MapApi";
    let src = "https://maps.googleapis.com/maps/api/js?key=" + await data["key"] + "&libraries=places&language=en"
    script.src = `${src}`;
    script.async = true
    script.defer = true
    this._renderer2.appendChild(this._document.body, script);
    if (session == undefined || session == '') {
      localStorage.removeItem("U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=")
      let storedata = {
        key: data['key'],
        date: moment().format('YYYY-MM-DD').toString()
      }
      localStorage.setItem("U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=", this.ApiService.EncryptObject(JSON.stringify(storedata)))
    }
    this.checkChnageInKey()
    // session = JSON.parse(localStorage.getItem("Map_Key"))
    // console.log(session.date)
    // console.log(session.date.toString() +" "+ moment().format('YYYY-MM-DD').toString())
    // console.log(session.date.toString() != moment().format('YYYY-MM-DD').toString())

  }
  async checkChnageInKey() {
    let req = {
      settingKey: "Google_Api_Key"
    }
    let data = await this.http.post(environment.ApiUrl + SN.getSettingData, { fshdjfdh: this.ApiService.EncryptObject(req) }).toPromise().catch((e) => {
      return e
    });
    data = this.ApiService.DecryptObject(data["QYUEIMSHNSGMDM"])["data"]
    let session
    if (localStorage.getItem('U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=') != null) {
      session = JSON.parse(this.ApiService.DecryptObject(localStorage.getItem("U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=").toString()))
    }
    console.log(session)
    if (session.key.toString() != data["key"].toString()) {
      console.log("session updated")
      localStorage.removeItem("U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=")
      let storedata = {
        key: data['key'],
        date: moment().format('YYYY-MM-DD').toString()
      }
      localStorage.setItem("U2FsdGVkX19xz30x//4C8FeZuW+5qhcNkCnIR0koj40=", this.ApiService.EncryptObject(JSON.stringify(storedata)))
    }
    else {
      console.log("session is same")
    }
  }
  //   this.val = 1
  //   console.log(this.val)

  // return this.http.get("../../assets/daynamic.json")
  // }
  // getLocation() {
  //   let DOM=this;
  //   var options = {
  //     enableHighAccuracy: true,
  //     timeout: 1000,
  //     maximumAge: 0
  //   };


  //   function success(pos) {
  //     var crd = pos.coords;
  //     if(localStorage.getItem('UserCountryCode')=='')
  //     {

  //       DOM.ApiService.GetJson("https://api.bigdatacloud.net/data/reverse-geocode-client",{
  //         latitude : crd.latitude,
  //         longitude : crd.longitude
  //       }).pipe(first()).subscribe(
  //         result => {
  //           // if (DOM.subscription) {
  //           //   DOM.subscription.unsubscribe();
  //           // }
  //           DOM.subscription = DOM._sharedService.getAddUsuario(result['countryCode']).subscribe(
  //           status => {
  //             // console.log('app.component -> ', status);
  //           });
  //         }, 
  //         error => {
  //       });
  //     }
  //   }

  //   function error(err) {
  //     console.log(`ERROR(${err.code}): ${err.message}`);
  //   }

  //   if (navigator.geolocation) {
  //      navigator.permissions.query({name:'geolocation'}).then(function(permissionStatus) {
  //       console.log('geolocation permission state is ', permissionStatus.state);
  //       if(permissionStatus.state=='granted' || permissionStatus.state=='prompt')
  //       {
  //         navigator.geolocation.getCurrentPosition(success, error, options);
  //       }

  //       permissionStatus.onchange = function() {
  //         console.log('geolocation permission state has changed to ', this.state);
  //         if(this.state=='granted')
  //         {
  //           navigator.geolocation.getCurrentPosition(success, error, options);
  //         }
  //       };
  //     });
  //   } else {
  //     console.log("Geolocation is not supported by this browser.");
  //   }

  // }
}
