import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { NgxSpinnerModule } from 'ngx-spinner';
import { SnotifyModule, SnotifyService, ToastDefaults } from 'ng-snotify';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PartnerComponent } from './partner/Partner.component';
import { BeforeLoginComponent } from './before-login/before-login.component';
import { SignInLayoutComponent } from './sign-in-layout/sign-in-layout.component';
import { SharedService } from './_helper/shared.service';
// start add by dhiraj - 09-04-21
import { DefaultUrlSerializer, UrlSerializer, UrlTree } from '@angular/router';
import { SeoserviceService } from './Seoservice/seoservice.service';
import { StripePaymentComponent } from './stripe-payment/stripe-payment.component';
import { CancelPaymentComponent } from './cancel-payment/cancel-payment.component';
declare var $: any;
export class LowerCaseUrlSerializer extends DefaultUrlSerializer {
  parse(url: string): UrlTree {
    if (url.includes('Accommodation')) {
      return super.parse(url.toLowerCase());
    }
    return super.parse(url);
  }
}
// end add by dhiraj - 09-04-21

@NgModule({
  declarations: [
    AppComponent,
    PartnerComponent,
    BeforeLoginComponent,
    SignInLayoutComponent,
    StripePaymentComponent,
    CancelPaymentComponent,
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    NgxSpinnerModule,
    SnotifyModule,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    { provide:'SnotifyToastConfig', useValue:ToastDefaults },
    { provide: 'isBrowser', useValue: true },
    SnotifyService,
    {
      provide: UrlSerializer,
      useClass: LowerCaseUrlSerializer
    },SharedService,
    SeoserviceService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
