import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { map } from 'rxjs/operators';
import { environment } from "../../environments/environment";
import { Response, UserInfo } from '../_model/common';
import { Alert } from '../_helper/alert';
import { ActivatedRoute, Router } from '@angular/router';
import * as CryptoJS from 'crypto-js';


@Injectable({providedIn:"root"})

export class ApiService {
    private Response = new Response;
    private UserInfo = new UserInfo;

    constructor(
        private http:HttpClient,
        private Alert:Alert,
        private router: Router,
        private route: ActivatedRoute,

    ) { }

    get UserSession() {
        if (localStorage.getItem('UserInfo')) {
          return JSON.parse(localStorage.getItem('UserInfo'));
        } else {
          return this.UserInfo;
        }
    }

    CallApiService(ServiceName:string='', ReqData:any={}) {
        ReqData.Token = (this.UserSession.Token!='' ? this.UserSession.Token : environment.DefaultToken);
        ReqData.UserId = this.UserSession.UserId;
        ReqData.Source = environment.Source;
        ReqData.AppVersion = environment.AppVersion;
        ReqData.DeviceId = environment.DeviceId;
        ReqData.DeviceToken = environment.DeviceToken;
        // console.log(ReqData);

        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                Authorization: ReqData.Token,
            }),
        };
        //Encrypt Request
        // console.log(ReqData);
        if(environment.AppVersion!='1.0'){
            let encryptRequest = this.EncryptObject(ReqData);
            ReqData = {fshdjfdh : encryptRequest};
        }
        return this.http.post(environment.ApiUrl+ServiceName, ReqData, httpOptions).pipe(map(
            res => {
                console.clear();
                if(environment.AppVersion!='1.0'){
                    res = this.DecryptObject(res['QYUEIMSHNSGMDM']);
                }
                this.Response = JSON.parse(JSON.stringify(res));
                // console.log(this.Response);
                if (this.Response['status'] == '2') {
                    localStorage.removeItem('UserInfo');
                } else if (this.Response['status'] == '1') {
                    if (this.Response['alert']=='1') {
                        this.Alert.show(this.Response['message'], 'success');
                    }
                    if (localStorage.getItem('UserInfo')!=undefined && localStorage.getItem('UserInfo')!=null && this.Response['token']!='') {
                        let UserInfo = JSON.parse(localStorage.getItem('UserInfo'));
                        UserInfo.Token = this.Response['token'];
                        localStorage.setItem('UserInfo', JSON.stringify(UserInfo));
                    }
                } else {
                    if (this.Response['alert']=='1') {
                        this.Alert.show(this.Response['message'], 'error');
                    }
                }
                return this.Response;
            }
        ));
    }

    EncryptObject(Object:any) {
        let key = CryptoJS.enc.Utf8.parse(environment.DATA_SECRET_KEY);
        var IV_KEY = CryptoJS.enc.Utf8.parse(environment.DATA_SECRET_KEY.substr(0,16));
        var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(JSON.stringify(Object).toString()), key,{
                keySize: 256,
                iv: IV_KEY,
                mode: CryptoJS.mode.CBC
            });
        return encrypted.toString();
    }
    
    DecryptObject(EncryptObject:string) {
        try {
            let key = CryptoJS.enc.Utf8.parse(environment.DATA_SECRET_KEY);
            var IV_KEY = CryptoJS.enc.Utf8.parse(environment.DATA_SECRET_KEY.substr(0,16));
            var decrypted = CryptoJS.AES.decrypt(EncryptObject, key, {
                keySize: 256,
                iv: IV_KEY,
                mode: CryptoJS.mode.CBC
            });
            return JSON.parse(decrypted.toString(CryptoJS.enc.Utf8));
        } catch (error) {
            console.log(error);
            return 0;
        }
    }

    GetLiveLocation(){
        return this.http.get<any>('https://geolocation-db.com/json/').pipe(map(
            res => {
                return res;
            }
        ));
    }

    GetJson(Url : string,req){
        return this.http.get<any>(Url,req).pipe(map(
            res => {
                return res;
            }
        ));
    }

    getPositionAllow(): Promise<any>
    {
      return new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resp => {
            resolve({lng: resp.coords.longitude, lat: resp.coords.latitude});
        },
            err => {
            reject(err);
        });
      });
    }

    GetQueryString(){
        let QString = {};
        this.route.queryParams.subscribe(params => { QString = params; });
        return QString;
      }
}

