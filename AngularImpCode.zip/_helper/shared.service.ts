import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { SearchLocation,SeoData } from '../_model/shared';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  private addUsuarioSource = new BehaviorSubject<string>('');
  public addUsuario$ = this.addUsuarioSource.asObservable();

  private mapSearchData = new BehaviorSubject(new SearchLocation);
  public mapSearchData$ = this.mapSearchData.asObservable();

  private SeoDataData = new BehaviorSubject(new SeoData);
  public SeoDataData$ = this.SeoDataData.asObservable();

  private CommonServiceData = new BehaviorSubject<[]>([]);
  public CommonServiceData$ = this.CommonServiceData.asObservable();

  constructor() {
    this.addUsuario$.subscribe(status =>
      localStorage.setItem('UserCountryCode', status)
    );
  }

  getAddUsuario(status): Observable<string> {
    this.addUsuarioSource.next(status);
    return this.addUsuario$;
  }

  getMapSearchData(transferData:SearchLocation){
    this.mapSearchData.next(transferData);
  }

  getSeoData(SeoData : SeoData){
    this.SeoDataData.next(SeoData);
  }

  getCommonServiceList(ServiceData:[]): Observable<[]> {
    this.CommonServiceData.next(ServiceData);
    return this.CommonServiceData$;
  }
}


