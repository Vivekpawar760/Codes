import { DOCUMENT } from '@angular/common';
import { Inject, Injectable, Renderer2, RendererFactory2 } from '@angular/core';
import { Title, Meta, MetaDefinition, SafeHtml, DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { ApiService } from '@app/_helper';
import { SharedService } from '@app/_helper/shared.service';
import { AccSearchData, SEOData } from '@app/_model/accommodation';
import { environment } from '@environments/environment';
import { Observable } from 'rxjs';
import { first } from 'rxjs/operators';
import * as SN from '../api-service-list';

@Injectable({
  providedIn: 'root'
})
export class SeoserviceService {
  FAQScriptData:string = "";
  AccData : any;
  PageTitle :string = "Ocxee Student";
  AccSearchData = new AccSearchData;
  SEOData = new SEOData;
  private _renderer2: Renderer2;
  constructor(private title: Title, private meta: Meta,
    private ApiService: ApiService,
    private route: ActivatedRoute,
    private _sharedService: SharedService,
    @Inject(DOCUMENT) private _document: Document,
    rendererFactory: RendererFactory2,
    private sanitizer: DomSanitizer
    ) { 
      this._renderer2 = rendererFactory.createRenderer(null, null);
    }
  
  updateTitle(title: string){
    this.title.setTitle(title);
  }
  updateMetaTags(metaTags: MetaDefinition[]){
    if(metaTags){
      metaTags.forEach(m=> this.meta.updateTag(m));
    }
  }
  
  canActivate (
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
      // console.log("Call CanActive -----------------------------");
      // console.log(state.url);
      let PhoneCodeUrls = ['/contactus','/registration','/enquiry','/partnerwithus'];
      if(state.url.indexOf('/student-accommodation')>=0){ 
        
        let ScriptData = {
          "@context": "https://schema.org/", 
          "@type": "BreadcrumbList", 
          "itemListElement": [{
            "@type": "ListItem",
            "position": "1",
            "name": "Home Page",
            "item": environment.SiteURL
          },
          {
            "@type": "ListItem", 
            "position": "2", 
            "name": "Student Accommodation",
            "item": `${environment.SiteURL}student-accommodation`
          }]
        };
      
        const id = route.paramMap.get('id');
        
        if(id!=undefined && id!=null && id!=""){
          let CountryName=route.paramMap.get('country').split('-').join(' ');
          let CityName='';
          if(route.paramMap.get('city')) CityName=route.paramMap.get('city').split('-').join(' ');
          let ReqSEO = {
            'CountryName': CountryName,
            'CityName': CityName,
            'AccommodationID': id,
          }
          this.SeoContentForDetailPage(ReqSEO);
        }else if(route.paramMap.get('country')){
          let CountryName=route.paramMap.get('country').split('-').join(' ');
          let CityName='';
          if(route.paramMap.get('city')) CityName=route.paramMap.get('city').split('-').join(' ');
          let ReqSEO = {
            'CountryName': CountryName,
            'CityName': CityName,
          }
          var metaDescription = CityName != '' ? CityName : CountryName
          CityName = CityName != '' ? CityName + ', ' + CountryName : CountryName;
          this.SeoContentForListingPage(ReqSEO,metaDescription,CityName,state.url);
          this.SetPhoneCode();
          ScriptData['itemListElement'][2] = {
            "@type": "ListItem", 
            "position":"3", 
            "name": route.paramMap.get('country').split('-').join(' '),
            "item": `${environment.SiteURL}student-accommodation/${route.paramMap.get('country')}`  
          }
        }else{
          this.ServiceSeoSet(8);
        }

        if(route.paramMap.get('city')){
          ScriptData['itemListElement'][3] = {
            "@type": "ListItem", 
            "position": "4", 
            "name": route.paramMap.get('city').split('-').join(' '),
            "item": `${environment.SiteURL}student-accommodation/${route.paramMap.get('country')}/${route.paramMap.get('city')}`  
          }
        }
        // Set Create Script Dynamic 
        let urlScript = this._renderer2.createElement('script');
        urlScript.type = 'application/ld+json';
      
        urlScript.text = `${JSON.stringify(ScriptData)}`;
        this._renderer2.appendChild(this._document.body,urlScript);
        // console.log(urlScript)
      }else if(state.url.indexOf('/blog')>=0){   
        const slug = route.paramMap.get('pagetitle');
        this.BlogDetailSeoSet(slug);
      }else if(PhoneCodeUrls.includes(state.url)){
        this.SetPhoneCode();
      }else{
        let serviceseo = {
          "/international-student-insurance" : 1,
          "/pickup-drop-services" : 2,
          "/forex-services-international-students" : 3,
          "/travel-assistance-services" : 4,
          "/sim-card-assistance-services" : 5,
          "/foreign-money-transfer" : 6,
          "/student-accommodation" : 8,
          "/student-visa-assistance-services" : 9,
          "/international-student-loans-services" : 10,
          "/storage-and-essentials-services" : 11,
          "/internship-guidance" : 12,
          "/furniture-rentals-services" : 13,
          "/job-assistance-services" : 14,
          "/guarantorservices" : 15,
          "/financial-service" : 16,
          "/food-partner" : 17,
        }
        // console.log(serviceseo["/international-student-insurance"]);
        this.ServiceSeoSet(serviceseo[state.url]);
        // switch (state.url) {
        //   case "/international-student-insurance":
        //   this.ServiceSeoSet(1);
        //   break;
        //   case '/pickup-drop-services':
        //   this.ServiceSeoSet(2);
        //   break;
        //   case '/forex-services-international-students':
        //   this.ServiceSeoSet(3);
        //   break;
        //   case "/travel-assistance-services":
        //   this.ServiceSeoSet(4);
        //   break;
        //   case '/sim-card-assistance-services':
        //   this.ServiceSeoSet(5);
        //   break;
        //   case '/foreign-money-transfer':
        //   this.ServiceSeoSet(6);
        //   break;
        //   case "/student-accommodation":
        //   this.ServiceSeoSet(8);
        //   break;
        //   case '/student-visa-assistance-services':
        //   this.ServiceSeoSet(9);
        //   break;
        //   case "/international-student-loans-services":
        //   this.ServiceSeoSet(10);
        //   break;
        //   case '/storage-and-essentials-services':
        //   this.ServiceSeoSet(11);
        //   break;
        //   case '/internship-guidance':
        //   this.ServiceSeoSet(12);
        //   break;
        //   case '/furniture-rentals-services':
        //   this.ServiceSeoSet(13);
        //   break;
        //   case '/job-assistance-services':
        //   this.ServiceSeoSet(14);
        //   this.SetPhoneCode();
        //   break;
        //   case '/guarantorservices':
        //   this.ServiceSeoSet(15);
        //   break;
        //   case '/financial-service':
        //   this.ServiceSeoSet(16);
        //   break;
        //   case '/foodpartner':
        //   this.ServiceSeoSet(17);
        //   break;
        // }
        
      }
      return true;
  }

  BlogDetailSeoSet(slug){
    var req_data = {
      'PageSlug': slug
    }
    this.ApiService.CallApiService(SN.GetBlogDetail, req_data).pipe(first()).subscribe(
      resp => {
        if (resp.status == '1') {
          let BlogDetail = resp.data;
          // console.log(BlogDetail);
          var PageTitle = BlogDetail.SEOTitle;
          this.title.setTitle(PageTitle);
          this.meta.addTags([{
              name: 'description',
              content: BlogDetail.SEODes
            },
            {
              name: 'keywords',
              content: BlogDetail.SEOKeyword
            },
            { property: 'og:title', content: PageTitle },
            { property: 'og:description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
            { property: 'og:url', content: environment.SiteURL+''+'blog/'+''+slug},
            { property: 'og:image', content:BlogDetail.MediaImage}
          ]);
        } else {
          document.location.href = '/blog';
        }
    },
    error => {
      console.log(error + "---------------");
      return true;
    });
  }
  
  ServiceSeoSet(ServiceID){
    var req_data={
      "ServiceID": ServiceID,
    }
    this.ApiService.CallApiService(SN.GetServiceSeoContent, req_data).subscribe(
      resp => {
        let ServiceDetails=resp.data;
        this.title.setTitle(ServiceDetails['PageTitle']);
        this.meta.addTags([
          // { name: 'title', content: ServiceDetails['SeoTitle'] },
          { name: 'description', content: ServiceDetails['SeoDescription'] },
          { name: 'keywords', content: ServiceDetails['SeoKeyword'] },
          { property: 'og:title', content: ServiceDetails['SeoTitle'] },
          { property: 'og:description', content: ServiceDetails['SeoDescription'] },
          { property: 'og:url', content: environment.SiteURL+''+ServiceDetails['PageSlug'] },
          { property: 'og:image', content:environment.SiteURL+'/assets/images/og_ocxee.jpg'}
        ]);
        return true;
      },
      error => {
        console.log(error + "---------------");
        return true;
      });
  }

  SeoContentForDetailPage(ReqData){
    this.ApiService.CallApiService(SN.GetSEOConetentDetails, ReqData).subscribe(
      resp => {
        if (resp.status == '1') {
          this.AccData = resp.data;
          // console.log(this.AccData);
          // var propertyImage = this.AccData.gallery_list[0]['ImageUrl'] ? this.AccData.gallery_list[0]['ImageUrl'] : '';
          var CityName = (this.AccData['CityName'] != '' ? this.AccData['CityName'] : '');
          var Area = (this.AccData['Area'] != '' ? this.AccData['Area'] : '');
          var CountryName = (this.AccData['CountryName'] != '' ? this.AccData['CountryName'] : '');

          var city_country_keyword = (CityName != '' ? CityName + ' ' + CountryName : CountryName);
          var city_country = (CityName != '' ? CityName + ', ' + CountryName : CountryName);

          if((Area && Area!='') && Area!=CityName){
            city_country = Area + ', ' + (CityName != '' ? CityName + ', ' + CountryName : CountryName);
          }

          this.PageTitle =this.AccData['AccommodationName'] +' - '+ 'Student Accommodation in ' + city_country +  ' | Ocxee ';
          // this.titleService.setTitle(this.PageTitle);
          var mets_description = this.AccData['PropertyDescription'] != '' ? this.AccData['PropertyDescription'].substring(0, 120) + '...' : '';
          mets_description = mets_description.replace("<div>", "").replace("</div>", "").replace("<p>", "").replace("</p>", "").replace("<span>", "").replace("</span>", "").replace("<label>", "").replace("</label>", "");
          let SeoJsonArray = {
              metaTags: [
              {
                name: 'description',
                content: 'Student Accommodation near ' + city_country + '. ' + mets_description
              },
              {
                name: 'keywords',
                content: 'Student Accommodation ' + city_country_keyword + ', Student Accommodation in ' + city_country_keyword + ', Student Accommodation Near ' + city_country_keyword
              },
              { property: 'og:title', content: this.PageTitle },
              { property: 'og:description', content: 'Student Accommodation near ' + city_country + '. ' + mets_description },
              { property: 'og:url', content: this.AccData['AccommodationSlug'] },
              { property: 'og:image', content: this.AccData.gallery_list[0]?.ImageUrl || "" }
              ]
          }; 
          this.title.setTitle(this.PageTitle);
          if(SeoJsonArray['metaTags']){
            SeoJsonArray['metaTags'].forEach(m=> this.meta.updateTag(m));
          }
         return true;
        }
      },
      error => {
        console.log(error + "---------------");
        return true;
      });
  }

  SeoContentForListingPage(ReqSEO,metaDescription,CityState,stateurl){
    this.PageTitle = `Best Student Accommodation ${CityState} | Book now with ocxee today`;
    let Meta_Keyword = `Ocxee, ocxee.com, Student accommodation in ${CityState} `;
    var Meta_title = `Best Student Accommodation ${CityState} | Book now with ocxee today`;
    // var Meta_description = 'Best Student Accommodation in ' + metaDescription + ' – Find houses, flats, studios, private halls, etc. for both national & international students at affordable prices. Book now!';
    var Meta_description = `Explore the best student accommodation in ${metaDescription} . We offer safe,affordable & diverse student housing close to the university, all bills included. Book Now`;
    var Page_Header = `Best Student Accommodation in ${this.AccSearchData.Search}`;
    this.ApiService.CallApiService(SN.GetSEODescription, ReqSEO).pipe(first()).subscribe(
      resp => {
        if (resp.status == '1') {
          this.SEOData = resp.data;
          if (this.SEOData.SeoHeader.MetaTitle != '') {
            this.PageTitle = this.SEOData.SeoHeader.MetaTitle;
            Meta_title = this.SEOData.SeoHeader.MetaTitle
          }
          if (this.SEOData.SeoHeader.MetaDescription != '')
            Meta_description = this.SEOData.SeoHeader.MetaDescription;
          if (this.SEOData.SeoHeader.MetaKeyword != '')
            Page_Header = this.SEOData.SeoHeader.MetaKeyword;
        } else {
          this.SEOData = new SEOData;
        }

        this.title.setTitle(this.PageTitle);
        // this.PageHeader = Page_Header;
        this.meta.addTags([
          { name: 'description', content: Meta_description },
          { name: 'keywords', content: Meta_Keyword },
          { property: 'og:title', content: Meta_title },
          { property: 'og:description', content: Meta_description },
          { property: 'og:url', content: environment.SiteURL+''+stateurl},
          { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
        ]);

        this.FAQScriptData = this.SEOData.FaqQueryData;
        let FAQscript = this._renderer2.createElement('script');
        FAQscript.type = 'application/ld+json';
        // console.log(this.FAQScriptData)
        FAQscript.text = `${this.FAQScriptData}`;
        if(this.FAQScriptData) this._renderer2.appendChild(this._document.body,FAQscript);
        return true;
      },
      error => {
        console.log(error + "---------------");
        return true;
      });
  }

  SetPhoneCode(){
    // this.sharedService.getAddUsuario('IN');
    const DOM=this;
    var options = {
      enableHighAccuracy: true,
      timeout: 1000,
      maximumAge: 0
    };
    
    function success(pos) {
      var crd = pos.coords;
      if(localStorage.getItem('UserCountryCode')==''){
        DOM.ApiService.GetJson("https://api.bigdatacloud.net/data/reverse-geocode-client",{
          latitude : crd.latitude,
          longitude : crd.longitude
        }).pipe(first()).subscribe(
          result => {
            let subscription = DOM._sharedService.getAddUsuario(result['countryCode']).subscribe(
            status => {
              // console.log('app.component -> ', status);
            });
          }, 
          error => {
        });
      }
    }
    
    function error(err) {
      console.log(`ERROR(${err.code}): ${err.message}`);
    }

    if (navigator.geolocation) {
      try {
        navigator.permissions.query({name:'geolocation'}).then(function(permissionStatus) {
        //  console.log('geolocation permission state is ', permissionStatus.state);
         if(permissionStatus.state=='granted' || permissionStatus.state=='prompt')
         {
           navigator.geolocation.getCurrentPosition(success, error, options);
         }
         permissionStatus.onchange = function() {
           console.log('geolocation permission state has changed to ', this.state);
           if(this.state=='granted')
           {
             navigator.geolocation.getCurrentPosition(success, error, options);
           }
         };
       });
      } catch (error) {
        console.log(error);
        navigator.geolocation.getCurrentPosition(
          function(position) { /** won't be executed for such short timeout */ 
          success(position);
          // console.log(position);
          },
          function(positionError) {
            switch (positionError.code) {
            // PERMISSION_DENIED
            case 1:
              console.log('Permission denied')
              break
            // POSITION_UNAVAILABLE
            case 2:
              console.log('Permission allowed, location disabled')
              break
            // TIMEOUT
            case 3:
              console.log('Permission allowed, timeout reached')
              break
            }
          },
          {timeout: 0
          })
      }
    } else {
      console.log("Geolocation is not supported by this browser.");
    }
  }

  getSafeHTML(jsonLD: {[key: string]: any}): SafeHtml {
  const json = jsonLD ? JSON.stringify(jsonLD, null, 2).replace(/<\/script>/g, '<\\/script>') : ''; 
  // escape / to prevent script tag in JSON
  const html = `<script type="application/ld+json">${json}</script>`;
  
  return this.sanitizer.bypassSecurityTrustHtml(html);
  }
}

// Seo Data declare
export const 

HomeSeoData = {
  seo: {
    title: 'One stop solution for student services globally  -Ocxee',
    metaTags: [
      { name: 'title', content: 'One stop solution for student services globally  -Ocxee' },
      { name: 'description', content: 'Explore the best Student accommodation, insurance, SIM cards, job assistance, pickup and drop, forex, internship, guarantor services, etc. Book Now!' },
      { name: 'keywords', content: 'Student Accommodation, insurance, SIM Cards, Job Assistance, Pickup and Drop, Forex, Internship, Rent Guarantor Services, Student Immigration Services' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title',  content: 'One stop solution for student services globally  -Ocxee' },      
      { property: 'og:description' ,  content: 'Explore the best Student accommodation, insurance, SIM cards, job assistance, pickup and drop, forex, internship, guarantor services, etc. Book Now!' },
      { property: 'og:url' , content: environment.SiteURL+'' },
      { property: 'og:site_name' , content: environment.SiteURL+'' },
      // {property:"og:image:type", content:"image/jpeg"},
      { property:'twitter:card',content:'app'},
      { property:'twitter:site',content:'@Ocxee Ltd'},
      { property:'twitter:description',content:'Explore the best Student accommodation, insurance, SIM cards, job assistance, pickup & drop, forex, internship, guarantor services, etc globally. Browse 1.5 Million+ affordable beds available globally.'},
      { property:'twitter:app:name:iphone',content:'Ocxee'},
      { property:'twitter:app:id:iphone',content:'id1522856353'},
      { property:'twitter:app:name:ipad',content:'Ocxee'},
      { property:'twitter:app:id:ipad',content:'id1522856353'},
      { property:'twitter:app:name:googleplay',content:'Ocxee'},
      { property:'twitter:app:id:googleplay',content:''},
      { property:'twitter:app:country',content:''}
    ]
  }
},

enquiryData = {
  seo: {
    title: 'Service Enquiry | Ocxee',
    metaTags: [
      { name: 'title', content: 'Service Enquiry | Ocxee' },
      { name: 'description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:title', content: 'Service Enquiry | Ocxee' },
      { property: 'og:description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide'  },
      { property: 'og:url', content: environment.SiteURL+'/student-accommodation/enquiry' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

AboutData = {
  seo: {
    title: 'About Us- Best student immigration solutions globally | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Ocxee, ocxee.com, Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide, About Us, About Ocxee' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'About Us- Best student immigration solutions globally | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/about' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

TermsAndConditions = {
  seo: {
    title: 'Terms And Conditions | Ocxee',
    metaTags: [
      { name: 'title', content: 'Terms And Conditions | Ocxee' },
      { name: 'description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:title', content: 'Terms And Conditions | Ocxee' },
      { property: 'og:description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:url', content: environment.SiteURL+'/TermsAndConditions' },
      { property: 'og:image', content:environment.SiteURL+'/assets/images/og_ocxee.jpg'}
    ]
  }
},

Forgotpassword = {
  seo: {
    title: 'Forgot Password | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Forgot Password | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/Forgotpassword' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

faq = {
  seo: {
    title: 'faq | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'faq | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/faq' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},


career = {
  seo: {
    title: 'Careers- Best student immigration solutions globally | Ocxee',
    metaTags: [
      { name: 'title', content: 'Careers- Best student immigration solutions globally | Ocxee' },
      { name: 'description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { name: 'keywords', content: 'Ocxee, ocxee.com, Careers, Best student immigration solutions' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Careers- Best student immigration solutions globally | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/career' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

PrivacyPolicy = {
  seo: {
    title: 'Privacy Policy | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Privacy Policy | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/PrivacyPolicy' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},


changepassword = {
  seo: {
    title: 'Change Password | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Change Password | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/changepassword' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

myaccount = {
  seo: {
    title: 'My Account | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'My Account | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/myaccount' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

benefits = {
  seo: {
    title: 'Benefits | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Benefits | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/benefits' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

contactus = {
  seo: {
    title: 'Contact Us- Best student immigration solutions globally | Ocxee',
    metaTags: [
      { name: 'title', content: 'Contact Us- Best student immigration solutions globally | Ocxee' },
      { name: 'description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { name: 'keywords', content: 'Ocxee, ocxee.com, Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide, Contact Us, Ocxee Contact' },
      { property: 'og:title', content: 'Contact Us- Best student immigration solutions globally | Ocxee' },
      { property: 'og:description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:url', content: environment.SiteURL+'/contactus' },
      { property: 'og:image', content:environment.SiteURL+'/assets/images/og_ocxee.jpg'}
    ]
  },
},

enquiry = {
  seo: {
    title: 'International student accommodation Provider worldwide | Ocxee',
    metaTags: [
      { name: 'title', content: 'Service Enquiry | Ocxee' },
      { name: 'description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:title', content: 'Service Enquiry | Ocxee' },
      { property: 'og:description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide'  },
      { property: 'og:url', content: environment.SiteURL+'/enquiry' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

Payment = {
  seo: {
    title: 'Payment | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Payment | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/Payment' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

paynow = {
  seo: {
    title: 'Pay Now- Best student immigration solutions globally | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Paynow | Ocxee' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/paynow' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

emailverification = {
  seo: {
    title: 'Email Verification | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Email Verification - OCXEE' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/email-verification' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

feedback = {
  seo: {
    title: 'Feedback | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Feedback - OCXEE' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/feedback' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

unsubscribemail = {
  seo: {
    title: 'Unsubscrib Email | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Unsubscrib Email - OCXEE' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'/unsubscribemail' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

blog = {
  seo: {
    title: 'Blog- Articles and Guides for Students | Ocxee',
    metaTags: [
      { name: 'title', content: 'Blog | Ocxee' },
      { name: 'description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { name: 'keywords', content: 'Ocxee, ocxee.com, uides and articles you need to know about moving abroad by ocxee.com' },
      { property: 'og:title', content: 'Blog - OCXEE' },
      { property: 'og:description', content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:url', content: environment.SiteURL+'/blog' },
      { property: 'og:image', content:environment.SiteURL+'/assets/images/og_ocxee.jpg'}
    ]
  }
},

partnerwithus = {
  seo: {
    title: 'Become our Channel Partner | Ocxee',
    metaTags: [
      { name: 'description', content: 'Access a dedicated Channel Partner portal to easily track & manage all your enquiries. Sign up to become an Ocxee Channel Partner via our website.' },
      { name: 'keywords', content: 'Ocxee, ocxee.com, Channel Partner, Ocxee Partner' },
      { name: 'og:title', content: 'Partner With Us - OCXEE' },
      { name: 'og:description', content: 'Access a dedicated Channel Partner portal to easily track & manage all your enquiries. Sign up to become an Ocxee Channel Partner via our website.' },
      { name: 'og:url', content: environment.SiteURL+'/partnerwithus' },
      { name: 'og:image', content:environment.SiteURL+'/assets/images/og_ocxee.jpg'}
    ]
  }
},

NotFound = {
  seo: {
    title: 'Not Found | Ocxee',
    metaTags: [
      { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:type', content: 'website' },
      { property: 'og:title', content: 'Not Found - OCXEE' },
      { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
      { property: 'og:url', content: environment.SiteURL+'' },
      { property: 'og:image', content: environment.SiteURL+'/assets/images/og_ocxee.jpg' }
    ]
  }
},

channelpartner = {
  seo: {
    title: 'Become our Channel Partner | Ocxee',
    metaTags: [
      { name: 'title', content: 'Become our Channel Partner | Ocxee' },
      { name: 'description', content: 'Access a dedicated Channel Partner portal to easily track & manage all your enquiries. Sign up to become an Ocxee Channel Partner via our website.' },
      { name: 'keywords', content: 'Become our Channel Partner | Ocxee' },
      { property: 'og:title', content: 'Become our Channel Partner | Ocxee' },
      { property: 'og:description', content: 'Access a dedicated Channel Partner portal to easily track & manage all your enquiries. Sign up to become an Ocxee Channel Partner via our website.' },
      { property: 'og:url', content: environment.SiteURL+'/partnerwithus' },
      { property: 'og:image', content:environment.SiteURL+'/assets/images/og_ocxee.jpg'}
    ]
  },
}

;