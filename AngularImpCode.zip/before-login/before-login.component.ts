import { Component, Input, OnInit } from '@angular/core';
import { NgAnimateScrollService } from 'ng-animate-scroll';
import { ApiService, Loader, Alert } from '../_helper';
import { UserInfo, IsRemember } from '../_model/common';
import { first } from 'rxjs/operators';
import * as SN from '../api-service-list';
import { ActivatedRoute, Router } from '@angular/router';
import { JsonPipe } from '@angular/common';
import * as _ from "lodash";
import { SharedService } from '@app/_helper/shared.service';

declare var $: any;

@Component({
  selector: 'app-before-login',
  templateUrl: './before-login.component.html',
  styleUrls: ['./before-login.component.scss']
})
export class BeforeLoginComponent implements OnInit {
  UserInfo = new UserInfo;
  IsRemember = new IsRemember;
  IsCookiePolicyClose = '1';
  ServiceList:any = [];
  CustomServiceList=[];
  SubEmail: boolean = false;
  PartnerComponet = ['/myaccount', '/changepassword'];
  appdownloadlink : string = "";
  OcxeeDownload : boolean = false;
  @Input() MsaterCommonData: [] = [];
  constructor(
    private ApiService: ApiService,
    private Loader: Loader,
    private Alert: Alert,
    private animateScrollService: NgAnimateScrollService,
    private router: Router,
    private route: ActivatedRoute,
    private _sharedService: SharedService
  ) { }

  ngOnInit(): void {
    this.appdownloadlink = this.checkDevice();
    var checkStorage = localStorage.getItem('UserInfo');
    if ((checkStorage == undefined || checkStorage == null || checkStorage == "") && (this.PartnerComponet.indexOf(this.router.url) > -1 || this.PartnerComponet.indexOf(this.router.url.split('#')[0]) > -1)) {
      this.router.navigate(['/']);
    }
    var LoginPopup = this.route.snapshot.queryParamMap.get('loginpopup');
    var UserData = localStorage.getItem('UserInfo');
    if (LoginPopup && !UserData) {
      $('#LoginPopup').modal('show');
    }
    this.GetServiceList();
    if (localStorage.getItem('IsCookiePolicyClose')) {
      this.IsCookiePolicyClose = localStorage.getItem('IsCookiePolicyClose');
    }else{
      this.IsCookiePolicyClose = '0';
    }

    $(".header-mbl-menu").click(function () {
      $('.header-menu-wrap').addClass('sidebar-open');
      $('.header-menu-wrap').append('<div id="bodyClick"></div>');

      $('#bodyClick').click(function () {
        $('.header-menu-wrap').removeClass('sidebar-open');
        $('#bodyClick').remove();
      });
    });

    $(".menuservice").hover(function () {
      $('.submenu-wrap li').show();
      $('.submenu-wrap li').toggleClass("animate__lightSpeedInRight");
    });

    $(".foote-col-head").click(function () {
      $(this).parent().toggleClass("active"); //footer-list-group
    });

    var lastScroll = 0;
    $(document).ready(function ($) {
      $(document).on('click', '.cookies-policy .btn-close', function () {
        $(this).parent().parent().parent().parent().remove();
        localStorage.setItem('IsCookiePolicyClose', '1');
      });
      // $(window).on('load', function () {
      //   $('#ForgotPasswordPopup').modal('show');
      // });

      $(".forgt-password-link").click(function () {
        $("#LoginPopup").modal("hide");
        $("#ForgotPasswordPopup").modal("show");
      });

      $(document).scroll(function () {
        $(this).scrollTop() > 500 ? $(".back-to-top-main").fadeIn() : $(".back-to-top-main").fadeOut()
      }), $(".back-to-top-main").click(function () {
        return $("html, body").animate({
          scrollTop: 0
        }, 500)
      });

      // if($('.main-header-wrap').hasClass('header-fixed'))
      // {
      //   alert('sdfsd2222');
      // }
      // else{
      //   alert('55454');
      // }
      // $(".main-header-wrap").addClass("header-fixed");
      $(window).scroll(function () {
        setTimeout(function () { //give them a second to finish scrolling before doing a check
          var scroll = $(window).scrollTop();
          if ($('.main-header-wrap').hasClass('header-fixed')) {
            var height = $('.header-fixed').height();
            $(".room-category-nav-wrap").css({ top: height + 1 });
          }
          else {
            $(".room-category-nav-wrap").css({ top: '0px' });
          }
          if (scroll < 30) {
            $(".main-header-wrap").removeClass("header-fixed");
            $("body").removeClass("accstictitle");
          }
          else {
            if (scroll > lastScroll + 30) {
              $(".main-header-wrap").removeClass("header-fixed");
              $("body").removeClass("accstictitle");
            } else if (scroll < lastScroll - 30) {
              $(".main-header-wrap").addClass("header-fixed");
              $("body").addClass("accstictitle");
            }
          }
          lastScroll = scroll;
        }, 100);
      });

      if ($(window).innerWidth() <= 991) {
        $(function () {
          $(".menu-dropdown-main").on("click", function (e) {
            $(this).toggleClass('submenu-dropdown-open');
            e.stopPropagation()
          });
          $(document).on("click", function (e) {
            if ($(e.target).is(".menu-dropdown-main") === false) {
              $(".menu-dropdown-main").removeClass("submenu-dropdown-open");
            }
          });
        });
      }


    });

    if (localStorage.getItem('IsRemember')) {
      this.IsRemember = JSON.parse(localStorage.getItem('IsRemember'));
    }

    //Parth added
    let cc = window as any;
    cc.cookieconsent.initialise({
      palette: {
        popup: {
          background: "#319a90"
        },
        button: {
          background: "rgba(49,154,144,0.8)",
          text: "#fff"
        }
      },
      theme: "classic",
      content: {
        message: 'We use cookies to improve your experience. By continuing, you agree to our use of cookies. See our Privacy Policy.',
        dismiss: 'Got it!',
        link: 'Privacy Policy',
        href: "/PrivacyPolicy"
      }
    });
    // console.log(cc);
    this.SetTimeoutDownloaddAp();
    // this.ApiService.getPositionAllow();
  }

  userLogin(LoginData) {
    if (LoginData.IsRemember == false) {
      localStorage.removeItem('IsRemember');
    }
    LoginData.UserName = LoginData.UserName.toLowerCase();
    this.ApiService.CallApiService(SN.UserLogin, LoginData).pipe(first()).subscribe(
      resp => {
        // console.log('--------- call login ------------');
        // console.log(resp);
        let IsRemember = {
          'UserName': LoginData.UserName,
          'UserPassword': LoginData.UserPassword,
          'IsRemember': LoginData.IsRemember,
        };

        if (resp.status == '1') {
          this.UserInfo = resp.data;
          this.UserInfo.Token = resp.token;
          localStorage.setItem('UserInfo', JSON.stringify(this.UserInfo));

          if (this.UserInfo.UserId != undefined && this.UserInfo.UserId != null && LoginData.IsRemember == true) {
            localStorage.setItem('IsRemember', JSON.stringify(IsRemember));
          }

          // this added by Hasmukhbhai command
          window.location.reload();

          $('#LoginPopup').modal('hide');
        }
      },
      error => {
        this.Loader.hide();
        this.Alert.show(error.statusText, 'error');
      });
  }

  get UserSession() {
    if (localStorage.getItem('UserInfo')) {
      return JSON.parse(localStorage.getItem('UserInfo'));
    } else {
      return this.UserInfo;
    }
  }

  userLogout() {
    localStorage.removeItem('UserInfo');
    window.location.reload();
    this.Alert.show('User logout successfully.', 'success');
  }

  userForgot(ForgotData) {
    this.Loader.show();
    var req_data = {
      'UserName': ForgotData.Email
    }
    this.ApiService.CallApiService(SN.UserForgetPassword, req_data).pipe(first()).subscribe(
      resp => {
        this.Loader.hide();
        if (resp.status == '1') {
          $('#ForgotPasswordPopup').modal('hide');
        }
      },
      error => {
        this.Loader.hide();
        this.Alert.show(error.statusText, 'error');
      });
  }

  GoUp() {
    this.animateScrollService.scrollToElement('maincontent', 300)
    // window.scrollTo(0, 0);
  }
  
  GetServiceList() {
    // this.Loader.show();
    this.ApiService.CallApiService(SN.GetServiceList).pipe(first()).subscribe(
      resp => {
         this.ServiceList = _.filter(resp.data.service_list, function (item) {
          return item.Status === 1
        });
        this.ServiceList = _.map(this.ServiceList, function(x) {
          x.PageSlug = ('/'+x.PageSlug);
          return x;
        });
        this.CustomServiceList = resp.data.CustomServiceList;
        this.ServiceList = _.concat(this.ServiceList,this.CustomServiceList);
        this.ServiceList = _.orderBy(this.ServiceList, ['DisplayOrder'],['asc']);
        let subscription = this._sharedService.getCommonServiceList(this.ServiceList).subscribe(status => {
          // console.log('app.component -> ', status);
        });
      },
      error => {
        // this.Loader.hide();
        this.Alert.show("something went wrong in serviceslist", 'error');
      });
  }

  CheckEmail() {
    var email = $('.Email').val();
    if (this.IsEmail(email) == false && email.length > 3) {
      this.SubEmail = true;
    } else {
      this.SubEmail = false;
    }
  }
  
  Subscription() {
    var email = $('.Email').val();
    if (this.IsEmail(email) == false || email == '') {
      this.SubEmail = true;
      return false;
    }
    $('.EmailLoader').show();
    $('.SendButton').prop('disabled', true);
    this.ApiService.CallApiService(SN.EmailSubscribe, { Email: email }).pipe(first()).subscribe(
      resp => {
        this.SubEmail = false;
        $('.EmailLoader').hide();
        $('.SendButton').prop('disabled', false);
        if (resp.status == '1') {
          $('.Email').val('');
          this.Alert.show(resp.message, 'success');
        } else {
          this.Alert.show(resp.message, 'error');
        }
      },
      error => {
        this.Loader.hide();
        $('.EmailLoader').hide();
        $('.SendButton').prop('disabled', false);
        this.Alert.show(error.statusText, 'error');
      })
  }

  IsEmail(email) {
    var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!regex.test(email)) {
      return false;
    } else {
      return true;
    }
  }


  ShowPass(input: any): any {
    input.type = input.type === 'password' ? 'text' : 'password';
  }

  menumodalclos(Url:string){
    $('.header-menu-wrap').removeClass('sidebar-open');
    $('#bodyClick').remove();
    $('.submenu-wrap li').hide();
    this.router.navigate(['/'+Url]);
  }

  checkDevice(){
    let android = "https://play.google.com/store/apps/details?id=com.dnk.ocxee";
    let ios = "https://apps.apple.com/in/app/ocxee/id1522856353"; 
    if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i)){
      return android;
    }else if(navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i)){
      return ios
    } else {
      return android;
    }
  }

  SetTimeoutDownloaddAp(){
    var hours = 24;
    var now = new Date().getTime();
    var setupTime = localStorage.getItem('DownloadMldalPC');
    if(!setupTime){
      this.OcxeeDownload = true;
    }
    let setupTime2 = JSON.parse(setupTime);
    // console.log(now-setupTime2 +'>'+ hours*60*60*1000);
    if(now-setupTime2 > hours*60*60*1000) {
      localStorage.removeItem('DownloadMldalPC');
      this.OcxeeDownload = true;
    }else{
      this.OcxeeDownload = false;
    }
  }

  CloseDownloaddApp(){
    var now = new Date().getTime();
    localStorage.setItem('DownloadMldalPC',JSON.stringify(now));
    this.OcxeeDownload = false;
  }

  // Redirect(){
  //   // this.router.navigate( ['/myaccount'], {fragment: tab});
  //   // window.location.href = '/myaccount'+tab;
  //   // console.log(window.location.pathname);
  //   let Arry = window.location.pathname.split('/');
  //   if(window.location.pathname!="/" ){
  //     setTimeout(() => {
  //       location.reload();
  //     }, 100);
  //   }
  // }
}
