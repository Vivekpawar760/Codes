export class SearchLocationData {
    Location:string = '';
    LocationCountry:string = '';
    LocationState:string = '';
    LocationCity:string = '';
    Latitude:string = '';
    Longitude:string = '';
}

export class EnquiryFormData {
    ServiceID:any;
    UserId:string = '0';
    ChannelPartnerID:string = '0';
    InquiryType:string = '';
    ServiceTypeID:any;
    FirstName:string = '';
    LastName:string = '';
    Email:string = '';
    PhoneNo:string = '';
    PhoneNo_CountryCode:any;
    Remark:string = '';
    CurrentCity:string = '';
    CurrentState:string = '';
    CurrentCountry:string = '';
    CurrentLocation:string = '';
    DestinationCity:string = '';
    DestinationState:string = '';
    DestinationCountry:string = '';
    DestinationLocation:string = '';
    PropertyType:any;
    // PriceCurrency:string='';
    MinPrice:string = '';
    MaxPrice:string = '';
    MinNoOfRooms:any;
    MaxNoOfRooms:any;
    UniversityName:string = '';
    MoveInDate:string = '';
    DurationInMonth:any;
    // AccLocation:string = '';
    NoOfPerson:any;
    // LoanCurrency:string = '';
    LoanAmount:string = '';
    TravelDate:string = '';
    DepatureDate:string = '';
    JourneyDate:string = '';
    CurrencyCode:string = '';
    CurrencySymbol:string = '';
    Descriptions:string = '' ;
    IsRefer:number=0;
}

export class ShowServiceWisePara {
    CurrentLocation:boolean = false;
    DestinationLocation:boolean = false;
    Remark:boolean = false;

    InsuranceType:boolean = false;
    PropertyType:boolean = false;
    MinPrice:boolean = false;
    MaxPrice:boolean = false;
    MinNoOfRooms:boolean = false;
    MaxNoOfRooms:boolean = false;
    UniversityName:boolean = false;
    MoveInDate:boolean = false;
    DurationInMonth:boolean = false;
    // AccLocation:boolean = false;
    AccNoOfPerson:boolean = false;
    LoanAmount:boolean = false;
    TravelDate:boolean = false;
    TravelNoOfPerson:boolean = false;
    DepatureDate:boolean = false;
    JourneyDate:boolean = false;
    AccLocation:boolean = false;
}