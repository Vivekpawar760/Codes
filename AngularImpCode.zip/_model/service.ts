export class ServiceResponse {
    ServiceID: string = '0';
    ServiceName: string = '';
    ImageUrl: string = '';
    PageTitle: string = '';
    SeoTitle: string = '';
    SeoDescription: string='';
    SeoKeyword: string='';
    banner_data:ImageUrlList[];
    IsSearch:string ='';
    provider_data:ProviderData[];
    section_data:SectionData[];
    testimonial_data:any[]=[];
}

export class SearchLocationData {
    Location:string = '';
    LocationCountry:string = '';
    LocationState:string = '';
    LocationCity:string = '';
    Latitude:string = '';
    Longitude:string = '';
}

interface ImageUrlList {
    Title:string;
    Description:string;
    ImageUrl:string;
}

interface ProviderData {
    Id:string;
    Title:string;
    List:ProviderList[];
}

interface ProviderList {
    ProviderID:string;
    ProviderName:string;
    ProviderUrl:string;
    BtnName:string;
    ShortDescription:string;
    LongDescription:string;
    ImageUrl:string;
    IsApi:string;
}

interface SectionData {
    Type:string;
    Title:string;
    Description:string;
    List:SectionList[];
}

interface SectionList {
    Title:string;
    Description:string;
    ImageUrl:string;
}

export class GurantorServicesBindForm {
    Name:string="";
    Email:string="";
    CurrentLocation:string="";
    WeeklyRent:string="";
    PhoneNo:string="";
    PhoneNo_CountryCode:string="";
    Agree:string="";
    Remark:string="";
}

export class SearchTaxiData {
    start_point:string="";
    end_point:string="";
    passengers:number=1;
    start_time_date:string="";
    start_time_time:string="";
    luggage_pieces:number=1;
    pname:string="";
}

export class FoodPartnerPageData {
    FoodProviderData:any[]=[];
    PopularOffers:any[]=[];
    CurrentPage:any;
    TotalPage:any;
    TotalRecord:any
}