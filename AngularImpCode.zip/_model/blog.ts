export class BlogList
{
    CurrentPage:number= 0;
    TotalPage:number= 0;
    TotalRecord:number= 0;
    List:List1[]=[];
    HeaderBlog:any=new  HeaderBlog;
}

class List1
{
    BlogID: string; 
    BlogTitle: string;
    BlogCategory: string;
    PageDescription: string;
    MediaImage: string; 
    ThumbImage: string; 
    EntryDate: string;
    SecondDiff: string;
    Category: string;
    Tags: string; 
    TimeLabel: string; 
    FilterID:string;
    link:string;
    BlogLikes:string;
    BlognewComponent :string;
    Isliked:number;
    IsLike:number;
}


 class HeaderBlog  {
    BlogID: string; 
    BlogTitle: string;
    MediaImage: string; 
    EntryDate: string;
    SecondDiff: string;
    Category: string;
    Tags: string; 
    TimeLabel: string; 
    link:string; 
}

export class CategoryList {
    Id:string;
    Name:string;
}

export class CategoryCountList {
    Id:string;
    Name:string;
    CountCategoory:string;
}

export class GetRecentBlogList
{
    List:RecentBlogList[]=[];
}

export class RecentBlogList {
    BlogID: string; 
    BlogTitle: string;
    MediaImage: string;
    ThumbImage: string;
    SecondDiff: string;
    Category: string;
    Tags: string; 
    TimeLabel: string;
    link:string; 
}

export class BlogFilter {
    PageNo:string='1';
    Limit:string='12';
    BlogCategory:string='';
    Search:string='';
}

export class StaticData{
    RecentBlog:RecentBlogList[]=[];
    HeaderBlog:any=new  HeaderBlog;
    CategoryList:CategoryCountList[]=[];
}

export class BlogDetail{
    BlogID:number=0;
    BlogTitle:string="";
    MediaImage:string="";
    Description:string="Loading...";
    Body:string="";
    SecondDiff:number;
    Category:string="";
    Tags:string="";
    TimeLabel:string="";
    SEOTitle:string="";
    SEOKeyword:string="";
    SEODes:string="";
    BlogComments:string="";
    BlogLikes:string="";
    IsLike:number=0;
    CategoryID:number=0;
}


