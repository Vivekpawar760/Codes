export class SearchLocation {
    Search:string = '';
    CountryName:string = '';
    StateName:string = '';
    CityName:string = '';
    AreaName:string = '';
    Latitude:number = 0;
    Longitude:number = 0;
}

export class SeoData {
    title:string = '';
    metaTags:any=[];
}

export class location {
    CountryCode:string = '';
}