export class SearchLocationData {
    Location:string = '';
    LocationCountry:string = '';
    LocationState:string = '';
    LocationCity:string = '';
    Latitude:string = '';
    Longitude:string = '';
}

export class AccSearchData
{
    PageNo:string = '1';
	Limit:string = '30';
    IsSearch:string = '0';
    Search:string = '';
    CountryName:string = '';
    StateName:string = '';
    CityName:string = '';
    AreaName:string = '';
    Latitude:number=0;
    Longitude:number=0;
    // Latitude:number = 51.5073509;
    //Longitude:number = -0.1277583;
    DistanceRadius:number = 5;
    PropertyTypeId:any[] = ["137"];
    MinBed:string='0';
    MaxBed:string='0';
    MinPrice:string = '';
    MaxPrice:string = '';
    SortBy:string;
    PageToken:string='';
    CurrencySymbol:string='';
    MoveinDate:string='';
    MoveoutDate:string='';
}


export interface MapMarker {
	AccomID:string;
	Latitude:number;
	Longitude:number;
	Label?:string;
    Content?:string;
    IsShown:boolean;
    Icon:string;
}

export class AccDataList {
	AccommodationID:string;
    UniqueID:string;
    AccommodationName:string;
    AddressLine1:string;
    AddressLine2:string;
    Latitude:number;
    Longitude:number;
    AccRating:string;
    ImageUrl:string;
    ProviderName:string;
    ProviderImageUrl:string;
    Distance:number;
    RentType:string;
    NightlyRate:string;
    WeeklyRate:string;
    MonthlyRate:string;
    CurrencySymbol:string;
    TotalBeds:string;
    IsWishlist:string;
    ImageUrlList:ImageUrlList[];
    IsFeature:string;
    IsOffer:string;
    IsShown:boolean;
    IsInfoWin:boolean;
    Icon:string;
    Type:number;
    offer_list:any[];

}

export class AccDatatTemp {
	AccommodationID:string='';
    UniqueID:string='';
    AccommodationName:string='';
    AddressLine1:string='';
    AddressLine2:string='';
    Latitude:number;
    Longitude:number;
    AccRating:string='';
    ImageUrl:string='';
    ProviderName:string='';
    ProviderImageUrl:string='';
    Distance:number;
    RentType:string='';
    NightlyRate:string='';
    WeeklyRate:string='';
    MonthlyRate:string='';
    CurrencySymbol:string='';
    TotalBeds:string='';
    IsWishlist:string='';
    ImageUrlList:ImageUrlList[];
    IsFeature:string='';
    IsOffer:string='';
    IsShown:boolean=false;
    IsInfoWin:boolean=false;
    Icon:string='';
    Type:number=0;
    offer_list:any[];
}

interface ImageUrlList {
    ImageUrl:string;
    Caption:string;
}

export class AccommodationData {
    UniqueID:string = '';
    AccommodationID:string = '0';
    AccommodationName:string = '';
    CountryName:string = '';
    StateName:string = '';
    CityName:string = '';
    Area:string = '';
    BookedDate:any[] = [];
    AddressLine1:string = '';
    AddressLine2:string = '';
    Latitude:number;
    Longitude:number;
    PostCode:string = '';
    AccRating:string = '';
    AccSize:string = '';
    PropertyType:any[] = [];
    FeaturesKey:any[] = [];
    IsWishlist:string = '';
    MetaTitle:string = '';
    MetaKeyword:string = '';
    MetaDescription:string = '';
    RentType:string = '';
    NightlyRate:string = '0.00';
    WeeklyRate:string = '0.00';
    MonthlyRate:string = '0.00';
    CurrencySymbol:string = '';
    PropertyDescription:string = '';
    PropertyLink:string = '';
    ProviderID:string = '';
    ProviderName:string = '';
    ProviderImageUrl:string = '';
    AccommodationSlug:string = '';
    IsReview:string = '0';
    AccUpdateInfo:string='';
    ShareMessage:string = '';
    
    gallery_list:gallery_list[] = [];
    feature_list:any[] = [];
    offer_list:offer_list[] = [];
    room_list:SingleRoomData[] = [];
    rule_list:rule_list[] = [];
    utility_list:any[] = [];
    faq_list:faq_list[] = [];
    contact_list:any[] = [];
    extra_list:extra_list[] = [];
    review_data:any = {};
    properties_around_list:any[] = [];
    payment_list:any = {};
    content_list:any[] = [];
    Gender:number = 0;
    Age:string = "";
    IsOurSlug:boolean=false;
    AccommodationOutSlug:string=''
}
export class payment_list_obj {
    Title:string='Payment';
    Description:string="";
}  
interface gallery_list {
    Caption:string;
    Description:string;
    ImageUrl:string;
    MediaType:string;
}
interface offer_list {
    Title:string;
    Description:string;
}
interface rule_list {
    Rules:string;
    IsCommon:string;
}
interface faq_list {
    Question:string;
    Answer:string;
}
interface extra_list {
    Title:string;
    Description:string;
}

export class SingleRoomData {
    AccRoomCategoryID:string = '0';
    RoomCategory:string = '';
    RentTypeName:string = '';
    RentType:string = '';
    ShortDescription:string = '';
    CurrencySymbol:string = '';
    TotalRooms:string = '';
    CarpetArea:string = '';
    TotalBeds:string = '';
    DeposoitAmount:string = '';
    rent_list:room_rent_list[] = [];
    gallery_list:room_gallery_list[] = [];
    feature_list:any[] = [];
    TotalGuests:string='';
    TotalBathRooms:string='';
}

interface room_gallery_list {
    AccRoomCategoryID:string;
    Caption:string;
    Description:string;
    ImageUrl:string;
    MediaType:string;
}

export class room_rent_list {
    AccRoomCategoryID:string = '0';
    AccRoomCategoryRentID:string = '0';
    IntakeName:string = '';
    StartDate:string = '';
    EndDate:string = '';
    MinTenture:string = '2';
    MaxTenture:string = '0';
    NightlyRate:string = '0.00';
    WeeklyRate:string = '0.00';
    MonthlyRate:string = '0.00';
    DeposoitAmount:string = '0.00';
    Status:string = '0';
}

export class ReviewData {
    AverageRating:string = '0';
    FacilitiesRating:string = '0';
    LocationRating:string = '0';
    TransportationRating:string = '0';
    SafetyRating:string = '0';
    StaffRating:string = '0';
    ValueRating:string = '0';
    Review:string = '';
    TotalReview:string = '0';
    List:any[] = [];
}

export class BookingRequest {
    MoveInDate:string = '';
    MoveOutDate:string = '';
    Remark:string = '';
    PerNightRate:string = '0.00';
    RentAmount:string = '0.00';
    DepositAmount:string = '0.00';
    CleaningCharge:string = '0.00';
    EstimatedBills:string = '0.00';
    AdministratorFees:string='0.00';
    TotalAmount:string = '0.00';
    TotalDays:string = '0';
    RentComment:string = '';
}

export class ArrangeCallData {
    CallDate:string = '';
    CallTime:string = '';
    Message:string = '';
}

export interface PopularDestination {
    Title:string;
    Description:string;
    ImageUrl:string;
    CountryName:string;
    AccomodationLink:string;
    Latitude:string;
    Longitude:string;
}

export interface PopularProperties {
    Title:string;
    Description:string;
    ImageUrl:string;
    List:AccDataList[];
}

export class SEOData{
    SeoHeader:SEOHeader;
    SEOBody: SEOBody[];
    FaqQueryData:string=""
}

class SEOHeader {
    MetaTitle:string='';
    MetaDescription:string='';
    MetaKeyword:string='';
    CurrencySymbol:string=''
}

interface SEOBody{
    Title:string;
    Description:string;
}

export class AccPageData{
    ServiceID:string="";
    ServiceName:string="";
    ImageUrl:string="";
    PageTitle:string="";
    SeoTitle:string="";
    SeoDescription:string="";
    SeoKeyword:string="";
    banner_data:banner_data[] = [];
    IsSearch:string="";
    PopularCityList:PopularCityList[] = [];
    PopularPropertiesList:PopularPropertiesList[] = [];
    BlogList:BlogList[] = [];
    NewsList:NewsList[] = [];
    TestimonialData:TestimonialData[] = [];
}

interface banner_data {
    Title:string;
    Description:string;
    ImageUrl:string;
    Url:string;
}


interface PopularCityList{
    Title:string;
    Description:string;
    ImageUrl:string;
    CountryName:string;
    AccomodationLink:string;
    Latitude:string;
    Longitude:string;
}

export interface PopularPropertiesList{
    Title:string;
    Propoertiekey:string;
    Description:string;
    ImageUrl:string;
    List:PropertiesList[];
}

export class DividedPopularList{
    Title:string="";
    Propoertiekey:string="";
    Description:string="";
    ImageUrl:string="";
    List:PropertiesList[]=[];
}

interface PropertiesList {
	AccommodationID:string;
    UniqueID:string;
    AccommodationName:string;
    AddressLine1:string;
    AddressLine2:string;
    Latitude:number;
    Longitude:number;
    AccRating:string;
    ImageUrl:string;
    ProviderName:string;
    ProviderImageUrl:string;
    Distance:number;
    RentType:string;
    NightlyRate:string;
    WeeklyRate:string;
    MonthlyRate:string;
    CurrencySymbol:string;
    TotalBeds:string;
    IsWishlist:string;
    ImageUrlList:ImageUrlList[],
    IsFeature:string;
    IsOffer:string;
    AccommodationSlug:string;
}

interface BlogList{
    BlogID:string;
    BlogTitle:string;
    MediaImage:string;
    ThumbImage:string;
    RecentDate:string;
    link:string;
    SecondDiff:string;
}



interface NewsList{
    NewsID:string;
    Title:string;
    MediaURL:string;
    ThumbImage:string;
    RecentDate:string;
    SecondDiff:string;
}

interface TestimonialData{
    Name:string;
    Gender:string;
    Designation:string;
    CompanyName:string;
    CountryName:string;
    ServiceName:string;
    ImageUrl:string;
    VideoUrl:string;
    Description:string;
    Rating:string;
}

export class DividedNews{
    'A':NewsList[] = [];
    'B':NewsList[] = [];
    'C':NewsList[] = [];
    'D':NewsList[] = [];
    'E':NewsList[] = [];
}
export class DividedBanner{
    'A':banner_data[] = [];
    'B':banner_data[] = [];
}

export class NgFormObject{
    FirstName:string="";
    LastName:string="";
    Email:string="";
    MobileNo:string="";
    CountryID:string="";
    PageUrl:string="";
    Description:string="";
    UniversityName:string="";
    PhoneCode:string="";
    PhoneNo:string="";
}
