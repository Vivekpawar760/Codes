export class AccData
{
    CurrentPage:string= "0";
    TotalPage:string= "0";
    TotalRecord:string= "0";
    List:List1[]=[]
    IsLoad:boolean=false;

}

export class InqData
{
    CurrentPage:string= "0";
    TotalPage:string= "0";
    TotalRecord:string= "0";
    List:List2[]=[]
    IsLoad:boolean=false;
}

export class TexiBooking
{
    CurrentPage:string= "0";
    TotalPage:string= "0";
    TotalRecord:string= "0";
    List=[]
    IsLoad:boolean=false;
}
export class TexiBookingKList
{

}
export class WishData
{
    CurrentPage:string= "0";
    TotalPage:string= "0";
    TotalRecord:string= "0";
    List:List3[]=[]

}

export class RecommData
{
    CurrentPage:string= "0";
    TotalPage:string= "0";
    TotalRecord:string= "0";
    List:List4[]=[]

}

class List1 {
    BookingID:string="";
    AccommodationID:string="";
    AccommodationName:string="";
    AddressLine1:string="";
    AddressLine2:string="";
    Latitude:string="";
    Longitude:string="";
    AccRating:string="";
    ImageUrl:string="";
    ProviderName:string="";
    ProviderImageUrl:string="";
    RentType:string="";
    RentAmount:string="";
    DepositAmount:string="";
    TotalAmount:string="";
    CurrencySymbol:string="";
    NoOfDays:string="";
    BookingDate:string="";
    Status:string="";
    StartDate:string="";
    EndDate:string="";
    Remark:string="";
    IsWishlist:string="";
    RoomCategory:string="";
    IsReview:string="";
    ImageUrlList:ImageUrlList[]=[];
    IsFeature:string="";
    IsOffer:string="";
    AccommodationSlug:string="";
    IsstudentDetail:string="0";
    FormUrl:string=''
}

interface ImageUrlList {
    ImageUrl:string;
    Caption:string;
}

class List2 {
    InquiryID: string;
    InquiryNo: string;
    ServiceName: string;
    FullName: string;
    Email: string;
    PhoneNo: string;
    Status: string;
    EntryDate: string;
    WishDate : string ;
}

class List3 {
    AccommodationID:string;
    UniqueID:string;
    AccommodationName:string;
    AddressLine1:string;
    AddressLine2:string;
    Latitude:string;
    Longitude:string;
    AccRating:string;
    ImageUrl:string;
    ProviderName:string;
    ProviderImageUrl:string;
    Distance:string;
    RentType:string;
    NightlyRate: string;
    WeeklyRate: string;
    MonthlyRate: string;
    CurrencySymbol:string;
    TotalBeds:string;
    IsWishlist:string;
    feature_list:feature_list[]=[];
    ImageUrlList:ImageUrlList[]=[];
    IsFeature:string;
    IsOffer:string;
    AccommodationSlug:string;
}

class List4{
    Mail_Date: string;
    AccommodationID: string;
    UniqueID: string;
    AccommodationName: string;
    PropertyType: string;
    AccRating: string;
    Active: string;
    AddressLine1: string;
    AddressLine2: string;
    Distance: string;
    RentType: string;
    WeeklyRate: string;
    NightlyRate:string;
    MonthlyRate:string;
    CurrencySymbol: string;
    TotalBeds: string;
    ProviderName: string;
    ProviderImageUrl: string;
    IsWishlist: string;
    ImageUrlList:ImageUrlList[]=[];
    IsFeature:string;
    IsOffer:string;
    AccommodationSlug:string;
}

interface feature_list {
    Text:string;
    ImageUrl:string;
}

export class PaymentDetails{
    BookingID:string= "";
    CustAdd1:string= "";
    CustAdd2:string= "";
    CustAdd3:string= "";
    CustEmail:string= "";
    CustPCode:string= "+91";
    CustPhone:string= "";
    CustZipCode:string= "";
    CustomerFName:string= "";
    CustomerLName:string= "";
    DepositAmount:string= "";
    PlanName:string= "";
    RentAmount:string= "";
    ServiceID:string;
    cartId:string= "";
    currency:string= "";
    SerType:string= "";
    CustCountryCode:string= "";
}
export interface StatusList{
    Id:string;
    Name:string;
    ImageUrl:string;
}

// export class StudentDetail
// {
//     AddressLine1:string="";
//     AddressLine2:string="";
//     City:string="";
//     PreCity:string="";
//     CourseTitle:string="";
//     ZipCode:string="";
//     Nationality:string="";
//     EMC_ApartmentNumber:string="";
//     EMC_Area:string="";
//     EMC_City:string="";
//     EMC_Country:string="";
//     EMC_DateOfBirth:string="";
//     EMC_EmailAddress:string="";
//     EMC_FirstName:string="";
//     EMC_LastName:string="";
//     EMC_Relationship:string="";
//     EMC_Street:string="";
//     EMC_TelNo:string="";
//     EMC_Title:string="";
//     EMC_ZipCode:string="";
//     GI_ApartmentNumber:string="";
//     GI_Area:string="";
//     GI_City:string="";
//     GI_Country:string="";
//     GI_DateOfBirth:string="";
//     GI_EmailAddress:string="";
//     GI_FirstName:string="";
//     GI_LastName:string="";
//     GI_Relationship:string="";
//     GI_Street:string="";
//     GI_TelNo:string="";
//     GI_Title:string="";
//     GI_ZipCode:string="";
//     PreEndDate:string="";
//     FlatGenderType:string="";
//     LandlineNo:string="";
//     PropertyName1:string="";
//     PropertyName2:string="";
//     RoomClass:string="";
//     RoomType:string="";
//     RoomShareWith:string="";
//     SpecialRequirements:string="";
//     PreStartDate:string="";
//     TenancyLength:string="";
//     University:string="";
//     YearOfStudy:string="";
//     IsEmailOffer:string="";
//     IsEmailContact:string="";
//     PaymentOption:string="";
//     Payment:string="";
//     InstalmentType:string="";
//     StudentHappy:string="";
// }

export class StudentDetail
{
    Student_DetailID:number=0;
    BookingID:string="";
    StudentID:string="";
    ProviderID:string="";
    AccommodationID:string="";
    FirstName:string="";
    MiddleName:string="";
    LastName:string="";
    Nationality:string="";
    DateofBirth:string="";
    Gender:string="";
    EmailAddress:string="";
    PhoneNumber:string="";
    OtherPreferences:string="";
    CurrentUniversity:string="";
    DestinationUniversity:string="";
    YearofStudy:string="";
    Course:string="";
    GI_FirstName:string="";
    GI_LastName:string="";
    GI_Relationship:string="";
    GI_DateofBirth:string="";
    GI_EmailAddress:string="";
    GI_PhoneNumber:string="";
    GI_Address:string="";
    GI_City:string="";
    GI_State:string="";
    GI_Postalcode:string="";
    GI_Country:string="";
    Address:string="";
    City:string="";
    State:string="";
    Postalcode:string="";
    Country:string="";
    Active:string="";
    EntryDate:string="";
    EntryIP:string="";
    FormProcess:number;
}

export class MyOfferData
{
    CurrentPage:string= "0";
    TotalPage:string= "0";
    TotalRecord:string= "0";
    List=[]
    IsLoad:boolean=false;
}



