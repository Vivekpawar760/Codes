import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';
import { BeforeLoginComponent } from './before-login/before-login.component';
import { PartnerComponent } from './partner/Partner.component';
import { SignInLayoutComponent } from './sign-in-layout/sign-in-layout.component';
import { HomeComponent } from './home/home.component';
import { SeoserviceService } from './Seoservice/seoservice.service';
import * as Seo from './Seoservice/seoservice.service';


const routes: Routes = [
  // { path: '', redirectTo: 'home', pathMatch: 'full' },

  {
    path: '',
    component: BeforeLoginComponent,
    children: [
      { path: '', loadChildren: () => import('./home/home.module').then(m => m.HomeModule),data: Seo.HomeSeoData}
    ]
  },
  {
    path: '',
    component: SignInLayoutComponent,
    children: [
      { path: 'signup', loadChildren: () => import('./signup/signup.module').then(m => m.SignupModule) },
    ]
  },
  {
    path: '',
    component: BeforeLoginComponent,
    children: [
      // { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
      //   data: {
      //     seo: {
      //       title: 'Student Accommodation,Insurance, SIM cards, Education Loan, Visa Assistance Service Provider',
      //       metaTags: [
      //         { name: 'title', content: 'Student Accommodation,Insurance, SIM cards, Education Loan, Visa Assistance Service Provider' },
      //         { name: 'description', content: 'OCXEE is your one-stop solution for Students Accommodation, Insurance, SIM cards, Education Loan, Visa Assistance, Forex, Internship, Guaranteed Services, etc. Visit us now!' },
      //         { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      //         { property: 'og:locale', content: 'en_US' },
      //         { property: 'og:type', content: 'website' },
      //         { property: 'og:title',  content: 'International student accommodation Provider worldwide - OCXEE' },      
      //         { property: 'og:description' ,  content: 'OCXEE provides one-stop solutions like Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
      //         { property: 'og:url' , content: 'https://www.ocxee.com/' },
      //         { property: 'og:site_name' , content: 'https://www.ocxee.com/' },
      //         { property: 'og:image' ,  content:'https://www.ocxee.com/assets/images/og_ocxee.jpg'}
      //       ]
      //     }
      //   } 
      // },
      { path: 'roomdetails', loadChildren: () => import('./roomdetails/roomdetails.module').then(m => m.RoomdetailsModule) },
      // { path: 'roomlist', loadChildren: () => import('./roomlist/roomlist.module').then(m => m.RoomlistModule) },
      //{ path: 'accommodation', redirectTo:'student-accommodation',pathMatch: 'full', loadChildren: () => import('./accommodation/accommodation.module').then(m => m.AccommodationModule) },
      // { path: 'accommodation/enquiry', redirectTo:'student-accommodation/enquiry',pathMatch: 'full', loadChildren: () => import('./accommodationenquiry/accommodationenquiry.module').then(m => m.AccommodationenquiryModule) },
      // { path: 'accommodation/enquiry', redirectTo:'student-accommodation/enquiry',pathMatch: 'full', loadChildren: () => import('./not-found-component/not-found-component.module').then(m => m.NotFoundComponentModule)  },
      // { path: 'accommodation/:country', redirectTo:'student-accommodation/:country',pathMatch: 'full', loadChildren: () => import('./accommodationlist/accommodationlist.module').then(m => m.AccommodationlistModule) },
      // { path: 'accommodation/:country/:city', redirectTo:'student-accommodation/:country/:city',pathMatch: 'full', loadChildren: () => import('./accommodationlist/accommodationlist.module').then(m => m.AccommodationlistModule) },
      // { path: 'accommodation/:country/:city/:area',  redirectTo:'student-accommodation/:country/:city/:area',pathMatch: 'full', loadChildren: () => import('./accommodationlist/accommodationlist.module').then(m => m.AccommodationlistModule) },
      // { path: 'accommodation/:country/:city/:name=:id', redirectTo:'student-accommodation/:country/:city/:name=:id',pathMatch: 'full', loadChildren: () => import('./accommodationdetails/accommodationdetails.module').then(m => m.AccommodationdetailsModule) },
      // { path: 'accommodation/:country/:city/:name/:id', redirectTo:'student-accommodation/:country/:city/:name/:id',pathMatch: 'full', loadChildren: () => import('./accommodationdetails/accommodationdetails.module').then(m => m.AccommodationdetailsModule) },
      
      /************************ accommoation redirect to student-accommodatrion code   ************************ */
      { path: 'student-accommodation', loadChildren: () => import('./accommodation/accommodation.module').then(m => m.AccommodationModule),canActivate : [SeoserviceService]},
      // { path: 'student-accommodation/enquiry', loadChildren: () => import('./accommodationenquiry/accommodationenquiry.module').then(m => m.AccommodationenquiryModule) },
      { path: 'student-accommodation/enquiry', loadChildren: () => import('./not-found-component/not-found-component.module').then(m => m.NotFoundComponentModule),data: Seo.enquiryData },
      { path: 'student-accommodation/:country', loadChildren: () => import('./accommodationlist/accommodationlist.module').then(m => m.AccommodationlistModule) },
      { path: 'student-accommodation/:country/:city', loadChildren: () => import('./accommodationlist/accommodationlist.module').then(m => m.AccommodationlistModule),canActivate : [SeoserviceService]},
      { path: 'student-accommodation/:country/:city/:area', loadChildren: () => import('./accommodationlist/accommodationlist.module').then(m => m.AccommodationlistModule),canActivate : [SeoserviceService]},
      { path: 'student-accommodation/:country/:city/:name=:id', loadChildren: () => import('./accommodationdetails/accommodationdetails.module').then(m => m.AccommodationdetailsModule) },
      { path: 'student-accommodation/:country/:city/:name/:id', loadChildren: () => import('./accommodationdetails/accommodationdetails.module').then(m => m.AccommodationdetailsModule),canActivate : [SeoserviceService]},
      
      { path: 'about', loadChildren: () => import('./aboutus/aboutus.module').then(m => m.AboutusModule),data: Seo.AboutData},
      { path: 'TermsAndConditions', loadChildren: () => import('./terms-and-conditions/terms-and-conditions.module').then(m => m.TermsAndConditionsModule),data: Seo.TermsAndConditions},
      { path: 'Forgotpassword', loadChildren: () => import('./forgotpassword/forgotpassword.module').then(m => m.ForgotpasswordModule),data: Seo.Forgotpassword },
      { path: 'faq', loadChildren: () => import('./faq/faq.module').then(m => m.FaqModule),data: Seo.faq },
      { path: 'career', loadChildren: () => import('./career/career.module').then(m => m.CareerModule),data: Seo.career},
      { path: 'PrivacyPolicy', loadChildren: () => import('./privacy-policy/privacy-policy.module').then(m => m.PrivacyPolicyModule),data: Seo.PrivacyPolicy },
      { path: 'changepassword', loadChildren: () => import('./changepassword/changepassword.module').then(m => m.ChangepasswordModule),  data: Seo.changepassword },
      { path: 'myaccount', loadChildren: () => import('./myaccount/myaccount.module').then(m => m.MyaccountModule),data: Seo.myaccount},
      { path: 'benefits', loadChildren: () => import('./benefits/benefits.module').then(m => m.BenefitsModule),data: Seo.benefits},
      { path: 'contactus', loadChildren: () => import('./contactus/contactus.module').then(m => m.ContactusModule),canActivate : [SeoserviceService],  data: Seo.contactus },
      
      { path: 'insurance',redirectTo:'international-student-insurance',loadChildren: () => import('./insurance/insurance.module').then(m => m.InsuranceModule),canActivate : [SeoserviceService] },
      { path: 'visa-assistance',redirectTo:'student-visa-assistance-services', loadChildren: () => import('./visa-assistance/visa-assistance.module').then(m => m.VisaAssistanceModule),canActivate : [SeoserviceService]},
      { path: 'education-loan', redirectTo:'international-student-loans-services',loadChildren: () => import('./education-loan/education-loan.module').then(m => m.EducationLoanModule),canActivate : [SeoserviceService] },
      { path: 'travel-assistance', redirectTo:'travel-assistance-services',loadChildren: () => import('./travel-assistance/travel-assistance.module').then(m => m.TravelAssistanceModule),canActivate : [SeoserviceService]},
      { path: 'forex', redirectTo:'forex-services-international-students',loadChildren: () => import('./forex/forex.module').then(m => m.ForexModule),canActivate : [SeoserviceService]},
      { path: 'sim-card', redirectTo:'sim-card-assistance-services',loadChildren: () => import('./sim-card/sim-card.module').then(m => m.SimCardModule),canActivate : [SeoserviceService]},
      { path: 'pickup-drop', redirectTo:'pickup-drop-services',loadChildren: () => import('./pickup-drop/pickup-drop.module').then(m => m.PickupDropModule),canActivate : [SeoserviceService]},
      { path: 'money-transfer', redirectTo:'foreign-money-transfer',loadChildren: () => import('./money-transfer/money-transfer.module').then(m => m.MoneyTransferModule),canActivate : [SeoserviceService]},
      { path: 'essentials', redirectTo:'storage-and-essentials-services',loadChildren: () => import('./essentials/essentials.module').then(m => m.EssentialsModule),canActivate : [SeoserviceService]},
      { path: 'internship', redirectTo:'internship-guidance',loadChildren: () => import('./internship/internship.module').then(m => m.InternshipModule),canActivate : [SeoserviceService]},
      { path: 'furniture-rentals', redirectTo:'furniture-rentals-services',loadChildren: () => import('./furniture-rentals/furniture-rentals.module').then(m => m.FurnitureRentalsModule),canActivate : [SeoserviceService]},
      
      //New Service Slug
      { path: 'international-student-insurance',loadChildren: () => import('./insurance/insurance.module').then(m => m.InsuranceModule),canActivate : [SeoserviceService] },
      { path: 'student-visa-assistance-services', loadChildren: () => import('./visa-assistance/visa-assistance.module').then(m => m.VisaAssistanceModule),canActivate : [SeoserviceService]},
      { path: 'international-student-loans-services', loadChildren: () => import('./education-loan/education-loan.module').then(m => m.EducationLoanModule),canActivate : [SeoserviceService] },
      { path: 'travel-assistance-services', loadChildren: () => import('./travel-assistance/travel-assistance.module').then(m => m.TravelAssistanceModule),canActivate : [SeoserviceService]},
      { path: 'forex-services-international-students', loadChildren: () => import('./forex/forex.module').then(m => m.ForexModule),canActivate : [SeoserviceService]},
      { path: 'sim-card-assistance-services', loadChildren: () => import('./sim-card/sim-card.module').then(m => m.SimCardModule),canActivate : [SeoserviceService]},
      { path: 'pickup-drop-services', loadChildren: () => import('./pickup-drop/pickup-drop.module').then(m => m.PickupDropModule),canActivate : [SeoserviceService]},
      { path: 'foreign-money-transfer', loadChildren: () => import('./money-transfer/money-transfer.module').then(m => m.MoneyTransferModule),canActivate : [SeoserviceService]},
      { path: 'storage-and-essentials-services', loadChildren: () => import('./essentials/essentials.module').then(m => m.EssentialsModule),canActivate : [SeoserviceService]},
      { path: 'internship-guidance', loadChildren: () => import('./internship/internship.module').then(m => m.InternshipModule),canActivate : [SeoserviceService]},
      { path: 'furniture-rentals-services', loadChildren: () => import('./furniture-rentals/furniture-rentals.module').then(m => m.FurnitureRentalsModule),canActivate : [SeoserviceService]},
      { path: 'job-assistance-services', loadChildren: () => import('./jobassistance/jobassistance.module').then(m => m.JobassistanceModule),canActivate : [SeoserviceService] },
      { path: 'guarantorservices', loadChildren: () => import('./gurantorservices/gurantorservices.module').then(m => m.GurantorservicesModule),canActivate : [SeoserviceService] },
      { path: 'serviceprovider', loadChildren: () => import('./partnerwithus/partnerwithus.module').then(m => m.PartnerwithusModule),data:Seo.partnerwithus,canActivate : [SeoserviceService]},
      { path: 'coconutlearning', loadChildren: () => import('./coconot-learning/coconot-learning.module').then(m => m.CoconotLearningModule)},
      
      { path: 'enquiry', loadChildren: () => import('./enquiry/enquiry.module').then(m => m.EnquiryModule),canActivate : [SeoserviceService],data: Seo.enquiry},
      { path: 'Payment', loadChildren: () => import('./payment/payment.module').then(m => m.PaymentModule),data: Seo.Payment},
      { path: 'paynow', loadChildren: () => import('./paynow/paynow.module').then(m => m.PaynowModule),data: Seo.paynow },
      { path: 'Cancel-Payment', loadChildren: () => import('./cancel-payment/cancel-payment.module').then(m => m.CancelPaymentModule),
        data: {
          seo: {
            title: 'Cancel Payment | Ocxee',
            metaTags: [
              { name: 'description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
              { name: 'keywords', content: 'Students Accommodations, Insurance, Visa Assistance, Education Loan, Travel Assistance, Forex, Sim Card, Pickup & Drop Service worldwide' },
              { property: 'og:locale', content: 'en_US' },
              { property: 'og:type', content: 'website' },
              { property: 'og:title', content: 'Payment | Ocxee' },
              { property: 'og:description', content: 'OCXEE Ltd is a world leading marketplace offering services to international students who desire to complete their overseas education in a foreign country.' },
              { property: 'og:url', content: 'https://www.ocxee.com/Cancel-Payment' },
              { property: 'og:image', content: 'https://www.ocxee.com/assets/images/og_ocxee.jpg' }
            ]
          }
        }
      },  
      { path: 'email-verification', loadChildren: () => import('./email-verification/email-verification.module').then(m => m.EmailVerificationModule),data: Seo.emailverification },
      { path: 'feedback', loadChildren: () => import('./feedback/feedback.module').then(m => m.FeedbackModule),data: Seo.feedback},
      { path: 'unsubscribemail', loadChildren: () => import('./unsubscribe-email/unsubscribe-email.module').then(m => m.UnsubscribeEmailModule),data: Seo.unsubscribemail},
      // { path: 'blog', loadChildren: () => import('./blog/blog.module').then(m => m.BlogModule) },
      // { path: 'blogdetails', loadChildren: () => import('./blogdetails/blogdetails.module').then(m => m.BlogdetailsModule)},
      { path: 'blog/:pagetitle', loadChildren: () => import('./blogdetails/blogdetails.module').then(m => m.BlogdetailsModule),canActivate : [SeoserviceService]},
      { path: 'blog', loadChildren: () => import('./blognew/blognew.module').then(m => m.BlognewModule),data: Seo.blog },
      { path: 'newaccommodation', loadChildren: () => import('./newaccommodation/newaccommodation.module').then(m => m.NewaccommodationModule)},
      { path: 'new_insurance', loadChildren: () => import('./new-insurance/new-insurance.module').then(m => m.NewInsuranceModule)},
      { path: 'blognew1', loadChildren: () => import('./blognew1/blognew1.module').then(m => m.Blognew1Module) },
      { path: 'set-password', loadChildren: () => import('./set-password/set-password.module').then(m => m.SetPasswordModule) },
      { path: 'insurancenew', loadChildren: () => import('./insurancenew/insurancenew.module').then(m => m.InsurancenewModule) },
      { path: 'educationloannew', loadChildren: () => import('./educationloannew/educationloannew.module').then(m => m.EducationloannewModule) },
      { path: 'simcardnew', loadChildren: () => import('./simcardnew/simcardnew.module').then(m => m.SimcardnewModule) },
      { path: 'poststudywork', loadChildren: () => import('./poststudywork/poststudywork.module').then(m => m.PoststudyworkModule) },
      { path: 'booktaxi/:pname', loadChildren: () => import('./booktaxi/booktaxi.module').then(m => m.BooktaxiModule) },
      { path: 'bookedtaxi', loadChildren: () => import('./bookedtaxi/bookedtaxi.module').then(m => m.BookedtaxiModule) },
      { path: 'partnerwithus', loadChildren: () => import('./channelpartner/channelpartner.module').then(m => m.ChannelpartnerModule),data : Seo.channelpartner },
      { path: 'food-partner', loadChildren: () => import('./foodpartner/foodpartner.module').then(m => m.FoodpartnerModule),canActivate : [SeoserviceService] },
      { path: 'partner/:source', loadChildren: () => import('./cplanding/cplanding.module').then(m => m.CplandingModule) },
      { path: 'financial-service', loadChildren: () => import('./financial-service/financial-service.module').then(m => m.FinancialServiceModule),canActivate : [SeoserviceService] },
      { path: 'pickup-drop-provider/:pname', loadChildren: () => import('./pickup-drop-provider/pickup-drop-provider.module').then(m => m.PickupDropProviderModule) },  
     ]
  },
  {
    path: '',
    component: PartnerComponent,
    children: []
  },
  { path: 'registration', loadChildren: () => import('./registration/registration.module').then(m => m.RegistrationModule),canActivate : [SeoserviceService],},
  {
    path: '',
    component: BeforeLoginComponent,
    children: [
      { path: '**', loadChildren: () => import('./not-found-component/not-found-component.module').then(m => m.NotFoundComponentModule),data: Seo.NotFound},
      { path: '404', loadChildren: () => import('./not-found-component/not-found-component.module').then(m => m.NotFoundComponentModule) },
    ]
  },
];




@NgModule({
  imports: [RouterModule.forRoot(routes,{scrollPositionRestoration: 'enabled',
  anchorScrolling: 'enabled',
  scrollOffset: [0, 25]})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
