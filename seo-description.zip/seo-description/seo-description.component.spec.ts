import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeoDescriptionComponent } from './seo-description.component';

describe('SeoDescriptionComponent', () => {
  let component: SeoDescriptionComponent;
  let fixture: ComponentFixture<SeoDescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeoDescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeoDescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
