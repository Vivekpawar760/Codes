import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { SeoDescriptionRoutingModule } from './seo-description-routing.module';
import { SeoDescriptionComponent } from './seo-description.component';

import { DataTablesModule } from 'angular-datatables';
import { FormBuilder,FormsModule, FormGroup, Validators,ReactiveFormsModule } from '@angular/forms';
import { ConfirmDialogModule } from '../_helper/confirm-dialog/confirm-dialog.module';
import { AutocompleteLibModule } from 'angular-ng-autocomplete';
import { AngularEditorModule } from '@kolkov/angular-editor';


@NgModule({
  declarations: [SeoDescriptionComponent],
  providers: [DatePipe],
  imports: [
    CommonModule,
    SeoDescriptionRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    DataTablesModule,
    ConfirmDialogModule,
    AutocompleteLibModule,
    AngularEditorModule
  ]
})
export class SeoDescriptionModule { }
