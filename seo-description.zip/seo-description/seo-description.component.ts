import { Component, OnInit, ViewChild } from '@angular/core';
import { AllServiceService } from '../_services';
import { DataTableDirective } from 'angular-datatables';
import { PermissionService, alertsService, LoaderService } from '../_helper';
import { Router, ActivatedRoute } from '@angular/router';
import { SeoDescription } from '../_models';
import { first } from 'rxjs/operators';
import * as SN from '../ServiceName';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AngularEditorConfig } from '@kolkov/angular-editor';
import { ConfirmDialogService } from '../_helper/confirm-dialog/confirm-dialog.service';
import { DatePipe } from '@angular/common';
import * as _ from "lodash";
import { element } from 'protractor';
import { environment } from '../../environments/environment';
declare var $: any;

class DataTablesResponse {
  data: any[];
  draw: number;
  recordsFiltered: number;
  recordsTotal: number;
  Data: any[];
}

@Component({
  selector: 'app-seo-description',
  templateUrl: './seo-description.component.html',
  styleUrls: ['./seo-description.component.scss',
    './../../assets/css/style.scss']
})
export class SeoDescriptionComponent implements OnInit {

  //  common variable
  title = this.Permission.get_PageName('accommodation_seo_content');
  dtOptions: DataTables.Settings = {};
  @ViewChild(DataTableDirective, { static: false })
  datatableElement: DataTableDirective;
  SearchData = new SeoDescription;
  SeoContentForm: FormGroup;
  FAQContentForm: FormGroup;
  NearBySearchForm: FormGroup;
  submitted = false;
  submitted2 = false;

  //uniqe variable
  SeoDescriptionList = [];
  GetCountryList = [];
  GetCityList = [];
  SeoArray = [];
  FAQArray = []
  body = {};
  selectedCountryValue: string = "";
  selectedCityValue: string = "";
  row = [];
  IsFileUploaded: number = 2
  AddStudentForm: FormGroup;
  get forminput3() {
    return this.AddStudentForm.controls;
  }

  constructor(
    private Permission: PermissionService,
    private router: Router,
    private AllServiceService: AllServiceService,
    private loader: LoaderService,
    private formBuilder: FormBuilder,
    private alert: alertsService,
    private confirmDialogService: ConfirmDialogService,
    public datepipe: DatePipe
  ) {
    var Is_View = this.get_permission_access('accommodation_seo_content', 'IsView');
    if (Is_View == false) {
      this.router.navigate(['/AdminDashboard']);
    }
  }


  ngOnInit(): void {
    $(document).ready(function () {
      $('input[type="radio"]').click(function () {
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $(".showhidebox").not(targetBox).hide();
        $(targetBox).show();
      });
    });
    this.SeoContentForm = this.formBuilder.group({
      AccSeoID: [''],
      Type: [''],
      CountryID: ['', Validators.required],
      CityID: [''],
      SeoFormArray: this.formBuilder.array([]),
      MetaTitle: [''],
      MetaDescription: [''],
      MetaKeyword: [''],
      Active: [true]
    })
    this.FAQContentForm = this.formBuilder.group({
      AccSeoID: [''],
      CountryID: ['', Validators.required],
      CityID: [''],
      FAQFormArray: this.formBuilder.array([]),
      Active: [true]
    })
    this.NearBySearchForm = this.formBuilder.group({
      AccSeoID: [''],
      // Type: [''],
      CountryID: ['', Validators.required],
      CityID: [''],
      Title: [''],

      // Active: [true]
    })
    this.SeoFormArray().push(this.newSeoFormArray());
    this.FAQFormArray().push(this.newFAQFormArray());
    this.LoadData();
    this.GetCountry();
  }
  get forminput() {
    return this.SeoContentForm.controls;
  }
  get forminput2() {
    return this.FAQContentForm.controls;
  }
  SeoFormArray(): FormArray {
    return this.SeoContentForm.get("SeoFormArray") as FormArray
  }
  FAQFormArray(): FormArray {
    return this.FAQContentForm.get("FAQFormArray") as FormArray
  }
  get_permission_access(slug, Permission_type) {
    return this.Permission.get_permission_access(slug, Permission_type);
  }
  newSeoFormArray(): FormGroup {
    return this.formBuilder.group({
      Title: ['', Validators.required],
      DisplayOrder: [this.SeoFormArray().length + 1, Validators.required],
      Description: ['', Validators.required],
      AccSeoDetailsID: [0]
    })
  }
  newFAQFormArray(): FormGroup {
    return this.formBuilder.group({
      Question: ['', Validators.required],
      Answer: ['', Validators.required]
    })
  }
  addSeoFormArray() {
    this.SeoFormArray().push(this.newSeoFormArray());
  }
  addFAQFormArray() {
    this.FAQFormArray().push(this.newFAQFormArray());
  }
  RemoveSeoFormIndex(i) {
    let AccSeoDetailsID = <FormArray>this.SeoContentForm.controls.SeoFormArray.value[i].AccSeoDetailsID;
    if (AccSeoDetailsID) {
      this.confirmDialogService.confirmThis("Are you sure to delete?", () => {
        this.AllServiceService.CallService(SN.DeleteSubSeoDescription, { 'AccSeoDetailsID': AccSeoDetailsID }).pipe(first()).subscribe(resp => {
          if (resp.ZMessage['status'] == '1') {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "success");
          }
          else {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "error");
          }
        });
        this.SeoFormArray().removeAt(i);
      }, function () {

      })
    } else {
      this.SeoFormArray().removeAt(i);
    }
  }
  RemoveFAQFormIndex(i) {
    if (this.FAQArray.length > 0) {
      if (this.FAQArray.length <= i) {
        console.log(this.FAQArray.length <= i)
        this.FAQFormArray().removeAt(i);
        return
      }
      let req = {
        AccSeoID: this.FAQContentForm.controls.AccSeoID.value,
        index: i
      }
      this.confirmDialogService.confirmThis("Are you sure to delete?", () => {
        this.AllServiceService.CallService(SN.RemoveFAQDescription, req).pipe(first()).subscribe(resp => {
          this.FAQArray = []
          if (resp.ZMessage['status'] == '1') {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "success");
          }
          else {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "error");
          }
        });
        this.FAQFormArray().removeAt(i);
      }, function () {

      })
    } else {
      this.FAQFormArray().removeAt(i);
    }
  }
  Datatable() {
    this.datatableElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.draw();
    });
  }
  LoadData() {
    this.dtOptions = {
      destroy: true,
      pagingType: 'simple_numbers',
      pageLength: 25,
      serverSide: true,
      processing: true,
      lengthMenu: [25, 50, 100, 150, 200, 250],
      dom: "<'row'<'col-sm-12'tr>>" +
        "<'row tbl-footer-row align-items-center'<'col-sm-12 col-md-4 pl-2'i><'col-sm-12 col-md-4 text-center'l><'col-sm-12 col-md-4 pr-2'p>>",
      scrollX: true,
      language: {
        paginate: {
          next: '<i class="fa fa-angle-right" title="Next"></i>',
          previous: '<i class="fa fa-angle-left" title="Privious"></i>',
          first: '<i class="fa fa-angle-double-left" title="First"></i>',
          last: '<i class="fa fa-angle-double-right" title="Last"></i>'
        },
      },
      ordering: false,
      searching: false,

      ajax: (dataTablesParameters: any, callback) => {
        this.body = {
          CountryID: this.SearchData.CountryID,
          CityID: this.SearchData.CityID,
          Title: this.SearchData.Title,
          FromDate: this.SearchData.FromDate,
          ToDate: this.SearchData.ToDate,
          Active: this.SearchData.Active,
          Limit: dataTablesParameters.length,
          PageNo: (dataTablesParameters.start + dataTablesParameters.length) / dataTablesParameters.length
        }
        this.AllServiceService.CallService(SN.SeoDescriptionList, this.body).pipe(first()).subscribe(
          resp => {
            this.SeoDescriptionList = resp.Data['list'];
            callback({
              recordsTotal: resp.Data['page_data']['TotalRecord'],
              recordsFiltered: resp.Data['page_data']['TotalRecord'],
              data: []
            });
            if (resp.Data['page_data']['TotalRecord'] > 0)
              $(".dataTables_empty").css("display", "none");
            setTimeout(function () {
              $(window).trigger('resize');
            }, 100);
            $('.selectpicker').selectpicker({
              noneSelectedText: 'Select'
            });

          });
      },
    };

    $(document).ready(function () {
      setTimeout(function () {
        $(window).resize(function () {
          $('.datatable-height-fit-screen .dataTables_scrollBody').height($(window).height() - 205);
        });
        $(window).trigger('resize');
        // $('.datatable-columns-adjust').DataTable().columns.adjust()
      }, 200);

    });
  }
  onSearch() {
    this.Datatable();
    this.LoadData();
    $('#FilterPopup').modal('hide');
  }

  onReset() {
    this.clearFormArray(this.SeoFormArray());
    setTimeout(() => {
      this.SeoFormArray().push(this.newSeoFormArray());
    }, 100);
    this.SeoContentForm.reset();
    this.SeoContentForm.controls['Active'].setValue(true);
    this.SearchData.CountryID = "";
    this.SearchData.CityID = "";
    this.SearchData.Title = "";
    this.SearchData.FromDate = "";
    this.SearchData.ToDate = "";
    this.SearchData.Active = "";
    setTimeout(function () {
      $('.selectpicker').selectpicker('refresh');
    }, 100);
  }

  GetCountry() {
    this.AllServiceService.CallService(SN.CountryListService, { 'AllData': '1', 'PageNo': "0", "Limit": "1" }).pipe(first()).subscribe(resp => {
      this.GetCountryList = resp.Data['list'];
      setTimeout(function () {
        $('.selectpicker').selectpicker('refresh');
        $(window).trigger('resize');
      }, 100);
    });
  }
  // GetCity(req){
  //   this.loader.showLoader();
  //   this.AllServiceService.CallService(SN.GetCountryToCity,{'CountryID' : req}).pipe(first()).subscribe(resp => { 
  //     this.loader.hideLoader();
  //     this.GetCityList = resp.Data['list'];
  //     setTimeout(function () {
  //       $('.selectpicker').selectpicker('refresh');
  //       $(window).trigger('resize');
  //       }, 1000);
  //   });
  //   this.loader.showLoader();
  // }
  async GetCity(req, isloader = 0) {
    if (isloader === 0) this.loader.showLoader();
    let resp = await this.AllServiceService.CallService(SN.GetCountryToCity, { 'CountryID': req }).toPromise().catch((e) => {
      this.loader.hideLoader();
      this.alert.showAlerts('Something wrong', "error");
    });
    if (isloader === 0) this.SeoContentForm.controls['CityID'].setValue('');
    setTimeout(function () {
      $('.selectpicker').selectpicker('refresh');
      $(window).trigger('resize');
    }, 1000);
    // console.log(resp);
    if (isloader === 0) this.loader.hideLoader();
    console.log(isloader)
    this.GetCityList = await resp.Data['list'];
    return this.GetCityList
  }

  async OnEdit(index): Promise<void> {
    let EditData = this.SeoDescriptionList[index];
    this.SeoArray = EditData['Description'];
    let Data: any = [];
    this.clearFormArray(this.SeoFormArray());
    this.SetFormArray();
    let Control = this.SeoContentForm.controls;
    Control['AccSeoID'].setValue(EditData['AccSeoID']);
    Control['CountryID'].setValue(EditData['CountryID']);
    Control['SeoFormArray'].setValue(this.SeoArray || []);
    Control['MetaTitle'].setValue(EditData['MetaTitle']);
    Control['MetaDescription'].setValue(EditData['MetaDescription']);
    Control['MetaKeyword'].setValue(EditData['MetaKeyword']);
    Control['Active'].setValue(EditData['Active']);
    if (this.GetCityList.length > 0) {
      if (this.GetCityList[0].CountryID != EditData['CountryID'])
        Data = await this.GetCity(EditData['CountryID']);
    } else {
      Data = await this.GetCity(EditData['CountryID']);
    }
    if (Data) {
      Control['CityID'].setValue(EditData['CityID']);
    }
    setTimeout(function () {
      $('.selectpicker').selectpicker('refresh');
    }, 100);
  }
  async onFAQAdd(id) {
    this.submitted2=false
    let EditData = this.SeoDescriptionList[id];
    let resp = await this.AllServiceService.CallService(SN.GetFAQDescription, { 'AccSeoID': EditData['AccSeoID'] }).toPromise().catch((e) => {
      this.loader.hideLoader();
      this.alert.showAlerts('Something wrong', "error");
    });
    this.FAQArray = []
    if (resp.Data[0] != undefined) {
      let data = JSON.parse(resp.Data[0]['QueAndAns'])
      for (const [key, value] of Object.entries(data['mainEntity'])) {
        let obj = {
          Question: value['name'],
          Answer: value['acceptedAnswer']['text']
        }
        this.FAQArray.push(obj)
      }
    }
    else
      this.FAQArray = [{ Question: "", Answer: "" }]
    let Data: any = [];
    this.clearFormArray(this.FAQFormArray());
    this.SetFAQFormArray();
    let Control = this.FAQContentForm.controls;
    Control['AccSeoID'].setValue(EditData['AccSeoID']);
    Control['CountryID'].setValue(EditData['CountryID']);
    Control['FAQFormArray'].setValue(this.FAQArray || []);
    Control['Active'].setValue(EditData['Active']);
    if (this.GetCityList.length > 0) {
      if (this.GetCityList[0].CountryID != EditData['CountryID'])
        Data = await this.GetCity(EditData['CountryID']);
    } else {
      Data = await this.GetCity(EditData['CountryID']);
    }
    if (Data) {
      Control['CityID'].setValue(EditData['CityID']);
    }
    setTimeout(function () {
      $('.selectpicker').selectpicker('refresh');
    }, 100);
  }
  SetFormArray() {
    let control = <FormArray>this.SeoContentForm.controls.SeoFormArray;
    this.SeoArray.forEach(x => {
      this.SeoFormArray().push(this.newSeoFormArray());
    })
  }
  SetFAQFormArray() {
    let control = <FormArray>this.FAQContentForm.controls.FAQFormArray;
    this.FAQArray.forEach(x => {
      this.FAQFormArray().push(this.newFAQFormArray());
    })
  }


  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0)
    }
  }

  onFAQSubmit() {
    this.submitted2 = true;
    if (this.FAQContentForm.invalid) {
      return;
    }

    this.loader.showLoader();
    this.FAQContentForm.value.Active = this.FAQContentForm.value.Active == true ? '1' : '0';
    this.AllServiceService.CallService(SN.AddFAQDescription, this.FAQContentForm.value).pipe(first()).subscribe(data => {
      this.loader.hideLoader();
      if (data.ZMessage['status'] == '1') {
        $('#FAQAddPopup').modal('hide')
        this.alert.showAlerts(data.ZMessage['ErrorMessage'], "success");
        this.Datatable();
        this.submitted2 = false;
        this.clearFormArray(this.FAQFormArray());
        this.FAQContentForm.reset();
      }
      else {
        this.alert.showAlerts(data.ZMessage['ErrorMessage'], "error");
        this.FAQContentForm.reset();
      }
    });
  }
  onSubmit() {
    this.submitted = true;
    if (this.SeoContentForm.invalid) {
      return;
    }
    this.loader.showLoader();
    this.SeoContentForm.value.Active = this.SeoContentForm.value.Active == true ? '1' : '0';
    this.SeoContentForm.value.Type = '1';
    this.AllServiceService.CallService(SN.AddSeoDescription, this.SeoContentForm.value).pipe(first()).subscribe(data => {
      this.loader.hideLoader();
      if (data.ZMessage['status'] == '1') {
        $('#AddPopup').modal('hide')
        this.alert.showAlerts(data.ZMessage['ErrorMessage'], "success");
        this.Datatable();
        this.submitted = false;
        this.SeoContentForm.reset();
      }
      else {
        this.alert.showAlerts(data.ZMessage['ErrorMessage'], "error");
        this.SeoContentForm.reset();
      }
    });
  }

  onDelete(id) {
    this.confirmDialogService.confirmThis("Are you sure to delete?", () => {
      this.AllServiceService.CallService(SN.DeleteSeoDescription, { 'AccSeoID': id }).pipe(first()).subscribe(
        resp => {
          if (resp.ZMessage['status'] == '1') {
            $('#AddPopup').modal('hide')
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "success");
            this.Datatable();
            this.LoadData();
          } else {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "error");
            this.Datatable();
            this.LoadData();
          }
        });
    }, function () {

    })
  }

  Export() {
    this.loader.showLoader();
    let that = this;
    this.AllServiceService.CallService(SN.GenerateSeoContentExcel, this.body).pipe(first()).subscribe(data => {
      if (data.ZMessage['status'] == '1') {
        this.loader.hideLoader();
        let tmp = data.Data['JsonData'];
        tmp.forEach(function (item, index, object) {
          item.EntryDate = that.datepipe.transform(item.EntryDate, 'MMM d, y , h:mm a');
          item.UpdateDate = that.datepipe.transform(item.UpdateDate, 'MMM d, y , h:mm a');
        });
        this.AllServiceService.ExcelExport(tmp, this.title);
        this.alert.showAlerts(data.ZMessage['ErrorMessage'], "success");
      } else {
        this.alert.showAlerts(data.ZMessage['ErrorMessage'], "error");
      }
    });
  }

  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '200px',
    minHeight: '0',
    maxHeight: 'auto',
    width: 'auto',
    minWidth: '0',
    translate: 'yes',
    enableToolbar: true,
    showToolbar: true,
    placeholder: 'Enter text here...',
    defaultParagraphSeparator: '',
    defaultFontName: '',
    defaultFontSize: '',
    outline: true,
    fonts: [
      { class: 'arial', name: 'Arial' },
      { class: 'times-new-roman', name: 'Times New Roman' },
      { class: 'calibri', name: 'Calibri' },
      { class: 'comic-sans-ms', name: 'Comic Sans MS' }
    ],
    customClasses: [
      {
        name: 'quote',
        class: 'quote',
      },
      {
        name: 'redText',
        class: 'redText'
      },
      {
        name: 'titleText',
        class: 'titleText',
        tag: 'h1',
      },
    ],
    uploadUrl: 'v1/image',
    uploadWithCredentials: true,
    sanitize: false,
    toolbarPosition: 'top',
  };

  async onAdd(id) {
    let SeoData = this.SeoDescriptionList[id];
    this.loader.showLoader();
    this.row = [];
   
    await this.AllServiceService.CallService(SN.GetNearBySearchData, { 'AccSeoID': SeoData['AccSeoID'] }).pipe(first()).subscribe(
      async resp => {
        this.selectedCountryValue = SeoData['CountryID'];
        let Data: any = [];
        if (this.GetCityList.length > 0) {
          if (this.GetCityList[0].CountryID != SeoData['CountryID'])
            Data = await this.GetCity(SeoData['CountryID'], 1);
        } else {
          Data = await this.GetCity(SeoData['CountryID'], 1);
        }
        if (Data) {
          this.selectedCityValue = SeoData['CityID']
        }
        setTimeout(function () {
          $('.selectpicker').selectpicker('refresh');
        }, 100);
        $('#HiddenAccSeoID').val(SeoData['AccSeoID']);
        $('#HiddenAccSeoID2').val(SeoData['AccSeoID']);
        if (resp.ZMessage['status'] == '1') {
          if (resp.Data['list'].length > 0) {
            var NaerByData = resp.Data['list'];
            for (let i = 0; i < NaerByData.length; i++) {
              const obj = {
                title: NaerByData[i].Title,
                url: NaerByData[i].Url,
                type: NaerByData[i].Type,
                sequence: NaerByData[i].Sequence,
                status: NaerByData[i].Active,
                id: NaerByData[i].NearBySearchID
              }
              this.row.push(obj);

            }
            this.loader.hideLoader();
            $('#AddNearBySearchPopup').modal('show');
          } else {
            this.addTable();
            this.loader.hideLoader();
            $('#AddNearBySearchPopup').modal('show');
          }

        } else {
          this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "error");
          this.loader.hideLoader();
          this.Datatable();
          this.LoadData();
          $('#AddNearBySearchPopup').modal('hide');
        }
      });

  }
  addTable() {
    const obj = {
      title: '',
      url: '',
      type: [],
      sequence: '',
      status: '1',
      id: ''
    }
    this.row.push(obj)
  }

  async deleteRow(x, y) {
    this.loader.showLoader();
    var delBtn = confirm(" Do you want to delete ?");
    if (delBtn == true) {
      if (y !== '') {
        await this.AllServiceService.CallService(SN.RemoveNearBySearchData, { 'NearBySearchID': y }).pipe(first()).subscribe(
          async resp => {
            if (resp.ZMessage['status'] == '1') {
              this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "success");
              this.loader.hideLoader();
            } else {
              this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "error");
              this.loader.hideLoader();
            }

          });
      }
      this.loader.hideLoader();
      this.row.splice(x, 1);
    }
  }
  async editRow(x, y) {
    var that = this;
    this.loader.showLoader();
    if (y !== '') {
      var mainTable = $('#tablemain');
      var tr = mainTable.find('tbody tr:eq(' + x + ')');
      var errCount = 0;
      var mainArr = [];
      $(tr).find('td').each(function (index, td) {
        if ($(this).find('input').is(':checkbox')) {
          var checkval = '0';
          if ($(this).find('input').is(':checked')) {
            checkval = '1';
          } else {
            checkval = '0';
          }
          mainArr.push(checkval);
        } else {
          var values = $(this).find('input, select').val();
          if (values == '' && index != '5') {
            that.alert.showAlerts("Please Enter Required Field", "error");
            errCount++;
            return false;
          }
          mainArr.push(values);
        }
      });
      let req = {
        'NearBySearchID': y,
        'NearByDataArray': mainArr
      };
      await this.AllServiceService.CallService(SN.UpdateNearBySearchData, req).pipe(first()).subscribe(
        async resp => {
          if (resp.ZMessage['status'] == '1') {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "success");
            this.loader.hideLoader();
          } else {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "error");
            this.loader.hideLoader();
          }

        });
    }
  }
  onlyNumberKey(event) {
    return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
  }

  SubmitNearByData() {
    let countryid = this.selectedCountryValue;
    let cityid = this.selectedCityValue;
    let AccSeoID = $('#HiddenAccSeoID').val();
    if (countryid == undefined || countryid == '') {
      this.alert.showAlerts("Please Select Country", "error");
      return false;
    }
    if (cityid == undefined || cityid == '') {
      this.alert.showAlerts("Please Select City", "error");
      return false;
    }
    var that = this;
    var mainArr = [];
    var tmpArr = [];
    var mainTable = $('#tablemain');
    var tr = mainTable.find('tbody tr');
    var errCount = 0;
    tr.each(function () {
      tmpArr = [];
      $(this).find('td').each(function (index, td) {
        if ($(this).find('input').is(':checkbox')) {
          var checkval = '0';
          if ($(this).find('input').is(':checked')) {
            checkval = '1';
          } else {
            checkval = '0';
          }
          tmpArr.push(checkval);
        } else {
          var values = $(this).find('input, select').val();
          if (values == '' && index != '5') {
            that.alert.showAlerts("Please Enter Required Field", "error");
            errCount++;
            return false;
          }
          tmpArr.push(values);
        }
      });
      mainArr.push(tmpArr);
    });
    if (mainArr.length == 0) {
      this.alert.showAlerts("Please Enter Required Field", "error");
      errCount++;
      return false;
    }
    if (errCount == 0) {
      let req = {
        'AccSeoID': AccSeoID,
        'CountryID': countryid,
        'CityID': cityid,
        'NearByDataArray': mainArr
      };
      this.AllServiceService.CallService(SN.AddNearBySearchData, req).pipe(first()).subscribe(
        resp => {
          if (resp.ZMessage['status'] == '1') {
            $('#AddNearBySearchPopup').modal('hide')
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "success");
            this.Datatable();
            this.LoadData();
          } else {
            this.alert.showAlerts(resp.ZMessage['ErrorMessage'], "error");
            this.Datatable();
            this.LoadData();
          }
        });
    }

  }
  excelupload(file) {
    this.IsFileUploaded = 2
    if ($('#ExcelFIle').prop('files').length == 0)
      return
    if (file.target.files[0].type != "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
      this.IsFileUploaded = 1
      $('#ExcelFIle').val('')
      return
    }
  }
  onAddStudent2() {
    var file = $('#ExcelFIle').prop('files');
    if (file.length == 0) {
      this.IsFileUploaded = 0
      return
    }
    let countryid = this.selectedCountryValue;
    let cityid = this.selectedCityValue;
    let AccSeoID = $('#HiddenAccSeoID2').val();
    const formData = new FormData();
    formData.append('recfile', $('#ExcelFIle').prop('files')[0]);
    formData.append('CountryID', countryid);
    formData.append('CityID', cityid);
    formData.append('AccSeoID', AccSeoID);
    formData.append('UserID', environment.UserData['UserID']);
    formData.append('Source', environment.Source);
    formData.append('Token', environment.UserData['Token']);
    this.loader.showLoader();
    this.AllServiceService.CallService(SN.NearByDataAddByXls, formData)
      .pipe(first())
      .subscribe(
        data => {
          console.log(data)
          this.loader.hideLoader();
          if (data.ZMessage['status'] == '1') {
            $('#ExcelFIle').val('');
            $('#AddNearBySearchPopup').modal('hide')
            this.alert.showAlerts(data.ZMessage['ErrorMessage'], "success");
            this.Datatable();
          }
          else {
            if(data.Data['buf']!='')
            {
              this.AllServiceService.ExcelExport(JSON.parse(data.Data['buf']), data.Data['FileName']+"Error");
            }
            $('#ExcelFIle').val('');
            $('#AddNearBySearchPopup').modal('hide')
            this.alert.showAlerts(data.ZMessage['ErrorMessage'], "error");
            this.Datatable();
          }
        },
        error => {
          this.loader.hideLoader();
          this.alert.showAlerts(error.statusText, "error");
        });

  }
}